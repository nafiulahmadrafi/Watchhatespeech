# 🕊️ National Peace Tracker — PIBD
**Political Insights BD (PIBD)** | [pibbd.org](https://pibbd.org)
Developed by **Ahmad Rafi**

Real-time Bangla hate speech & misinformation detection platform.

---

## 🚀 Quick Deploy (Hostinger VPS)

```bash
git clone <repo> peaceshield
cd peaceshield
cp .env.example .env
# Edit .env — set SECRET_KEY
bash deployment/scripts/deploy.sh
```

**Access:**
- Frontend: `https://your-domain.com`
- API Docs: `https://your-domain.com/api/docs`
- Health:   `https://your-domain.com/health`

---

## 📁 Project Structure

```
peaceshield/
├── backend/
│   ├── app/
│   │   ├── main.py                    ← FastAPI entry point
│   │   ├── core/
│   │   │   ├── config.py              ← Settings (pydantic-settings)
│   │   │   └── logger.py              ← Loguru structured logging
│   │   ├── db/
│   │   │   ├── mongodb.py             ← Motor async client
│   │   │   └── indexes.py             ← MongoDB keyword indexes
│   │   ├── models/
│   │   │   └── schemas.py             ← Pydantic domain models
│   │   ├── api/v1/endpoints/
│   │   │   ├── analyse.py             ← POST /submit, POST /analyse
│   │   │   ├── dashboard.py           ← GET /dashboard, Peace Meter
│   │   │   └── scraper.py             ← Scraper management API
│   │   └── services/
│   │       ├── ai/engine.py           ← Bangla-BERT (hate-speech-report)
│   │       ├── repository/post_repo.py← MongoDB data access layer
│   │       └── scraper/
│   │           ├── engine_v4.py       ← 5-tier scraper engine (ULTRA)
│   │           ├── site_selectors.py  ← CSS selectors for 94+ portals
│   │           ├── news_portals.py    ← Portal registry + priority rotation
│   │           └── scheduler.py       ← APScheduler background cycles
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/
│   └── src/
│       ├── pages/index.tsx            ← Main app page
│       ├── components/portal/         ← Submit portal component
│       ├── hooks/useDashboard.ts      ← Auto-refresh hook
│       ├── store/useStore.ts          ← Zustand global state
│       └── styles/globals.css         ← Cyberpunk dark mode CSS
├── deployment/
│   ├── nginx/nginx.conf               ← Reverse proxy + SSL
│   └── scripts/deploy.sh             ← One-command VPS deploy
├── docker-compose.yml                 ← Full stack (app+mongo+nginx)
└── .env.example                       ← Environment template
```

---

## ⚙️ VPS Requirements

| Component        | RAM    |
|-----------------|--------|
| Bangla-BERT (int8) | ~750 MB |
| MongoDB          | ~500 MB |
| FastAPI + Playwright | ~400 MB |
| Next.js          | ~200 MB |
| **Total**        | **~2 GB** |

Recommended: **4 GB VPS** (Hostinger KVM 4)

---

## 🕷️ Scraper Coverage

| Category      | Portals | Interval |
|--------------|---------|---------|
| Priority 1 (BD TV + major papers) | 20 | 30 min |
| Priority 2 (All BD + Indian) | 30 | 60 min |
| Priority 3 (Asian + International) | 20 | 2 hours |

**5-tier fallback:** aiohttp → Playwright → Stealth → Google News RSS → Direct RSS

---

## 🤖 AI Model

**`hate-speech-report/bangla-bert-hate-speech`** (HuggingFace)
- Labels: `Hate` / `Offensive` / `Neutral`
- int8 quantised on CPU → ~750 MB RAM
- Batch inference via ThreadPoolExecutor (non-blocking)

---

## 📡 API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/submit` | Public text submission + AI verdict |
| POST | `/api/v1/analyse` | Raw text analysis |
| GET  | `/api/v1/dashboard` | Peace Meter + threat feed |
| GET  | `/api/v1/scraper/status` | Scheduler status |
| POST | `/api/v1/scraper/trigger` | Manual scrape cycle |
| GET  | `/api/v1/scraper/portals` | Portal registry |
| GET  | `/health` | System health |

---

## 🔑 Environment Variables

```env
SECRET_KEY=your-32-char-secret-key
MONGODB_URI=mongodb://mongo:27017
MONGODB_DB=peaceshield
BANGLA_BERT_MODEL=hate-speech-report/bangla-bert-hate-speech
DEVICE=cpu
SCRAPER_CONCURRENCY=3
SCRAPER_INTERVAL_MINUTES=30
ALLOWED_ORIGINS=["https://your-domain.com"]
NEXT_PUBLIC_API_URL=https://your-domain.com/api/v1
```

---

© Political Insights BD (PIBD) | Developed by Ahmad Rafi | pibbd.org
