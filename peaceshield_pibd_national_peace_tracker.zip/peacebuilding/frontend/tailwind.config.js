/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        cyber: {
          black:   "#080B0F",
          dark:    "#0D1117",
          panel:   "#111827",
          border:  "#1F2937",
          blue:    "#00F3FF",
          red:     "#FF003F",
          amber:   "#FFB800",
          green:   "#00FF9F",
          purple:  "#BF5FFF",
          text:    "#C9D1D9",
          muted:   "#6B7280",
        },
      },
      fontFamily: {
        mono:    ["'Share Tech Mono'", "monospace"],
        display: ["'Orbitron'", "monospace"],
        body:    ["'Noto Sans Bengali'", "'Noto Sans'", "sans-serif"],
      },
      animation: {
        "pulse-red":    "pulseRed 2s ease-in-out infinite",
        "scan":         "scan 3s linear infinite",
        "glitch":       "glitch 0.3s ease-in-out",
        "fade-up":      "fadeUp 0.4s ease-out",
        "neon-flicker": "neonFlicker 4s ease-in-out infinite",
      },
      keyframes: {
        pulseRed: {
          "0%, 100%": { boxShadow: "0 0 8px #FF003F40" },
          "50%":      { boxShadow: "0 0 24px #FF003F, 0 0 48px #FF003F40" },
        },
        scan: {
          "0%":   { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100vh)" },
        },
        glitch: {
          "0%":   { transform: "translateX(0)" },
          "25%":  { transform: "translateX(-4px) skewX(-2deg)" },
          "75%":  { transform: "translateX(4px) skewX(2deg)" },
          "100%": { transform: "translateX(0)" },
        },
        fadeUp: {
          from: { opacity: 0, transform: "translateY(12px)" },
          to:   { opacity: 1, transform: "translateY(0)" },
        },
        neonFlicker: {
          "0%, 95%, 100%": { opacity: 1 },
          "96%":           { opacity: 0.7 },
          "97%":           { opacity: 1 },
          "98%":           { opacity: 0.5 },
          "99%":           { opacity: 1 },
        },
      },
      boxShadow: {
        "cyber-blue": "0 0 20px #00F3FF40, 0 0 40px #00F3FF10",
        "cyber-red":  "0 0 20px #FF003F40, 0 0 40px #FF003F10",
        "neon-blue":  "0 0 8px #00F3FF, inset 0 0 8px #00F3FF20",
        "neon-red":   "0 0 8px #FF003F, inset 0 0 8px #FF003F20",
      },
      backgroundImage: {
        "grid-cyber": "linear-gradient(rgba(0,243,255,0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(0,243,255,0.03) 1px, transparent 1px)",
      },
      backgroundSize: {
        "grid-24": "24px 24px",
      },
    },
  },
  plugins: [],
};
