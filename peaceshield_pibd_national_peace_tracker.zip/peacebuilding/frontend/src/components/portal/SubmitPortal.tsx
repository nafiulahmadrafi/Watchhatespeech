// src/components/portal/SubmitPortal.tsx
"use client";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { submitText } from "@/lib/api";
import { useStore, type SubmissionResult } from "@/store/useStore";

const LABEL_COLORS: Record<string, string> = {
  Hate:      "#FF003F",
  Offensive: "#FFB800",
  Neutral:   "#00FF9F",
};

const EXAMPLES = [
  { label: "High Risk",   text: "এই সংখ্যালঘু দের দেশ থেকে বের করে দেওয়া উচিত, দাঙ্গা করতে হবে।" },
  { label: "Medium Risk", text: "সরকারের নির্বাচনী কারচুপি মানা যায় না, তীব্র প্রতিবাদ হওয়া উচিত।" },
  { label: "Low Risk",    text: "আজকের নির্বাচনে শান্তিপূর্ণভাবে ভোট দেওয়ার আহ্বান জানানো হয়েছে।" },
];

export default function SubmitPortal() {
  const { submitting, submissionResult, setSubmitting, setSubmissionResult } = useStore();
  const [text, setText] = useState("");
  const [hint, setHint] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async () => {
    if (text.trim().length < 5) {
      setError("কমপক্ষে ৫টি অক্ষর লিখুন / Please enter at least 5 characters.");
      return;
    }
    setError("");
    setSubmitting(true);
    setSubmissionResult(null);
    try {
      const result: SubmissionResult = await submitText(text, hint || undefined);
      setSubmissionResult(result);
    } catch (err) {
      setError("সংযোগ ব্যর্থ / Connection failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  const color = submissionResult ? LABEL_COLORS[submissionResult.label] : "#00F3FF";

  return (
    <div className="panel">
      <div className="panel-title">
        <span className="dot" style={{ background: "#FFB800", boxShadow: "0 0 8px #FFB800" }} />
        Public Submission Portal / জনসাধারণের রিপোর্ট পোর্টাল
      </div>

      <div className="portal-grid">
        {/* Input side */}
        <div className="submit-area">
          <div>
            <div className="cyber-label">সন্দেহজনক বিষয়বস্তু</div>
            <textarea
              className="cyber-textarea"
              placeholder="এখানে সন্দেহজনক পোস্ট বা মন্তব্য লিখুন..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              maxLength={2000}
            />
            <div className="char-count">{text.length} / 2000</div>
          </div>
          <div>
            <div className="cyber-label">Source Hint (optional)</div>
            <input
              className="cyber-input"
              placeholder="e.g. Facebook, WhatsApp..."
              value={hint}
              onChange={(e) => setHint(e.target.value)}
            />
          </div>
          {error && (
            <div style={{ fontFamily: "'Share Tech Mono',monospace", fontSize: 11, color: "#FF003F" }}>
              {error}
            </div>
          )}
          <button className="cyber-btn" onClick={handleSubmit} disabled={submitting}>
            {submitting ? (
              <><span className="spinner" /> ANALYSING...</>
            ) : (
              "◈ ANALYSE NOW"
            )}
          </button>

          {/* Examples */}
          <div style={{ marginTop: 16 }}>
            <div className="cyber-label" style={{ marginBottom: 8 }}>Quick Examples</div>
            {EXAMPLES.map((ex) => (
              <div
                key={ex.label}
                style={{
                  background: "rgba(255,255,255,.02)",
                  border: "1px solid rgba(255,255,255,.06)",
                  padding: "8px 10px",
                  marginBottom: 6,
                  cursor: "pointer",
                  fontSize: 12,
                  lineHeight: 1.5,
                }}
                onClick={() => setText(ex.text)}
              >
                <span style={{ fontFamily: "'Share Tech Mono',monospace", fontSize: 9, color: "#6B7280", marginRight: 8 }}>
                  {ex.label}
                </span>
                {ex.text}
              </div>
            ))}
          </div>
        </div>

        {/* Result side */}
        <div id="result-area">
          <AnimatePresence mode="wait">
            {!submissionResult && !submitting && (
              <motion.div
                key="placeholder"
                initial={{ opacity: 0 }} animate={{ opacity: 0.3 }} exit={{ opacity: 0 }}
                style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", minHeight: 200, gap: 8 }}
              >
                <div style={{ fontSize: 48, opacity: 0.15 }}>◎</div>
                <div style={{ fontFamily: "'Share Tech Mono',monospace", fontSize: 10, color: "#6B7280", letterSpacing: ".1em" }}>AWAITING INPUT</div>
              </motion.div>
            )}

            {submitting && (
              <motion.div
                key="loading"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", minHeight: 200, gap: 12 }}
              >
                <div className="spinner" style={{ width: 32, height: 32, borderWidth: 3 }} />
                <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 10, color: "#00F3FF", letterSpacing: ".1em" }}>BANGLA-BERT PROCESSING</div>
              </motion.div>
            )}

            {submissionResult && !submitting && (
              <motion.div
                key="result"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                style={{ border: `1px solid ${color}40`, padding: 16, boxShadow: `0 0 20px ${color}15` }}
              >
                <div style={{ fontFamily: "'Orbitron',monospace", fontSize: 22, fontWeight: 700, color, textAlign: "center", padding: "8px 0", textShadow: `0 0 16px ${color}` }}>
                  {submissionResult.label.toUpperCase()}
                </div>
                <div style={{ fontFamily: "'Share Tech Mono',monospace", fontSize: 10, color: "#6B7280", textAlign: "center", marginBottom: 12 }}>
                  Confidence: {Math.round(submissionResult.confidence * 100)}% — Risk: {Math.round(submissionResult.risk_score)}/100
                </div>
                <div style={{ height: 6, background: "rgba(255,255,255,.06)", marginBottom: 4, position: "relative" }}>
                  <div style={{
                    height: "100%",
                    width: `${submissionResult.risk_score}%`,
                    background: "linear-gradient(90deg, #00FF9F, #FFB800, #FF003F)",
                    transition: "width 1s cubic-bezier(.4,0,.2,1)"
                  }} />
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontFamily: "'Share Tech Mono',monospace", fontSize: 9, color: "#6B7280", marginBottom: 12 }}>
                  <span>Low</span><span>Medium</span><span>High</span><span>Critical</span>
                </div>
                <div style={{ fontSize: 12, textAlign: "center", color: "rgba(201,209,217,.8)", lineHeight: 1.5 }}>
                  {submissionResult.message}
                </div>
                <div style={{ marginTop: 10, fontFamily: "'Share Tech Mono',monospace", fontSize: 9, color: "#6B7280", textAlign: "center" }}>
                  ID: {submissionResult.submission_id?.slice(0, 8).toUpperCase()}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
