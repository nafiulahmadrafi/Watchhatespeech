// src/store/useStore.ts
import { create } from "zustand";

export type HateLabel = "Hate" | "Offensive" | "Neutral";

export interface PeaceMeter {
  score: number;
  level: "Critical" | "High" | "Medium" | "Low";
  hate_24h: number;
  offensive_24h: number;
  neutral_24h: number;
  total_24h: number;
  trend: "rising" | "falling" | "stable";
}

export interface Threat {
  id: string;
  content: string;
  source: string;
  label: HateLabel;
  risk_score: number;
  confidence: number;
  keywords_matched: string[];
  scraped_at: string;
}

export interface SubmissionResult {
  submission_id: string;
  label: HateLabel;
  confidence: number;
  risk_score: number;
  message: string;
}

interface AppState {
  // Dashboard
  peaceMeter: PeaceMeter | null;
  threats: Threat[];
  topKeywords: { keyword: string; count: number }[];
  lastRefresh: Date | null;
  dashboardLoading: boolean;

  // Submission
  submitting: boolean;
  submissionResult: SubmissionResult | null;

  // Actions
  setPeaceMeter: (m: PeaceMeter) => void;
  setThreats: (t: Threat[]) => void;
  setTopKeywords: (k: { keyword: string; count: number }[]) => void;
  setLastRefresh: () => void;
  setDashboardLoading: (v: boolean) => void;
  setSubmitting: (v: boolean) => void;
  setSubmissionResult: (r: SubmissionResult | null) => void;
}

export const useStore = create<AppState>((set) => ({
  peaceMeter: null,
  threats: [],
  topKeywords: [],
  lastRefresh: null,
  dashboardLoading: false,
  submitting: false,
  submissionResult: null,

  setPeaceMeter: (m) => set({ peaceMeter: m }),
  setThreats: (t) => set({ threats: t }),
  setTopKeywords: (k) => set({ topKeywords: k }),
  setLastRefresh: () => set({ lastRefresh: new Date() }),
  setDashboardLoading: (v) => set({ dashboardLoading: v }),
  setSubmitting: (v) => set({ submitting: v }),
  setSubmissionResult: (r) => set({ submissionResult: r }),
}));
