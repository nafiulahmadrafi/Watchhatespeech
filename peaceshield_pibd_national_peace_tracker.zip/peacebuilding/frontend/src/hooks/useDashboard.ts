// src/hooks/useDashboard.ts
import { useEffect, useCallback } from "react";
import { fetchDashboard } from "@/lib/api";
import { useStore } from "@/store/useStore";

export function useDashboard(intervalMs = 30_000) {
  const {
    setThreats, setPeaceMeter, setTopKeywords,
    setLastRefresh, setDashboardLoading,
  } = useStore();

  const load = useCallback(async () => {
    setDashboardLoading(true);
    try {
      const data = await fetchDashboard();
      setPeaceMeter(data.peace_meter);
      setThreats(data.recent_threats || []);
      setTopKeywords(data.top_keywords || []);
      setLastRefresh();
    } catch (err) {
      console.error("Dashboard fetch failed:", err);
    } finally {
      setDashboardLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const id = setInterval(load, intervalMs);
    return () => clearInterval(id);
  }, [load, intervalMs]);

  return { refresh: load };
}
