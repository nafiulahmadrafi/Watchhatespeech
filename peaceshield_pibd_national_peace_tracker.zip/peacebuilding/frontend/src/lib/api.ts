// src/lib/api.ts
import axios from "axios";

const BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api/v1";

export const api = axios.create({
  baseURL: BASE,
  timeout: 30_000,
  headers: { "Content-Type": "application/json" },
});

export async function fetchDashboard() {
  const { data } = await api.get("/dashboard");
  return data;
}

export async function submitText(content: string, sourceHint?: string) {
  const { data } = await api.post("/submit", {
    content,
    source_hint: sourceHint || null,
    reporter_type: "citizen",
  });
  return data;
}

export async function searchPosts(q: string) {
  const { data } = await api.get("/search", { params: { q, limit: 20 } });
  return data;
}
