// src/pages/index.tsx
import Head from "next/head";
import { useState } from "react";
import { useDashboard } from "@/hooks/useDashboard";
import { useStore } from "@/store/useStore";
import PeaceMeterWidget from "@/components/dashboard/PeaceMeterWidget";
import ThreatFeed from "@/components/dashboard/ThreatFeed";
import KeywordsPanel from "@/components/dashboard/KeywordsPanel";
import SubmitPortal from "@/components/portal/SubmitPortal";

type View = "dashboard" | "submit" | "feed";

export default function Home() {
  const [view, setView] = useState<View>("dashboard");
  const { refresh } = useDashboard(30_000);
  const { peaceMeter, threats, topKeywords, dashboardLoading } = useStore();

  return (
    <>
      <Head>
        <title>PeaceShield BD — Bangla Hate Speech Monitor</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#080B0F" />
        <link rel="manifest" href="/manifest.json" />
      </Head>

      <div className="app">
        {/* Nav */}
        <nav className="nav">
          <div className="logo">
            PEACE<span>SHIELD</span> BD
          </div>
          <div className="nav-tabs">
            {(["dashboard", "submit", "feed"] as View[]).map((v) => (
              <button
                key={v}
                className={`tab ${view === v ? "active" : ""}`}
                onClick={() => setView(v)}
              >
                {v === "dashboard" ? "◈ Dashboard" : v === "submit" ? "◎ Submit" : "◇ Feed"}
              </button>
            ))}
          </div>
        </nav>

        {/* Dashboard */}
        {view === "dashboard" && (
          <div>
            {peaceMeter && <PeaceMeterWidget meter={peaceMeter} loading={dashboardLoading} />}
            <KeywordsPanel keywords={topKeywords} />
            <ThreatFeed
              threats={threats.filter((t) => t.label !== "Neutral").slice(0, 8)}
              onRefresh={refresh}
            />
          </div>
        )}

        {/* Submit Portal */}
        {view === "submit" && <SubmitPortal />}

        {/* Full Feed */}
        {view === "feed" && (
          <ThreatFeed threats={threats} showSearch onRefresh={refresh} />
        )}
      </div>
    </>
  );
}
