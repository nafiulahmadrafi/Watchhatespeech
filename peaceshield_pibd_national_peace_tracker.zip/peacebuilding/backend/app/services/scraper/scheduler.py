"""
app/services/scraper/scheduler.py  (v2 — upgraded)

Smart Rotating Scheduler
=========================
Priority 1 (critical) → every 30 min (always)
Priority 2 (high)     → every 60 min (even cycles)
Priority 3 (medium)   → every 2 h    (every 4th cycle)

Cycle pipeline: scrape → keyword filter → AI batch → MongoDB upsert
Independent of n8n.
"""

import asyncio
from datetime import datetime
from typing import List

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from loguru import logger

from app.core.config import settings
from app.services.scraper.news_portals import get_portals_for_cycle, TOTAL_PORTALS, summary
from app.services.scraper.engine_v4 import run_scraper
from app.models.schemas import ScraperJob, JobStatus, Post

_cycle_number: int = 0
_scheduler: AsyncIOScheduler | None = None


async def _run_cycle() -> None:
    global _cycle_number

    from app.db.mongodb import get_db
    from app.services.repository.post_repo import PostRepository
    from app.services.ai.engine import get_engine

    db     = get_db()
    repo   = PostRepository(db)
    engine = get_engine()

    portals = get_portals_for_cycle(_cycle_number)
    p1 = sum(1 for p in portals if p["priority"] == 1)
    p2 = sum(1 for p in portals if p["priority"] == 2)
    p3 = sum(1 for p in portals if p["priority"] == 3)
    logger.info(f"Cycle #{_cycle_number} | {len(portals)} portals (P1={p1} P2={p2} P3={p3})")

    job = ScraperJob(keywords=[p["website"] for p in portals[:10]])
    await repo.create_job(job)

    loop        = asyncio.get_event_loop()
    concurrency = min(settings.SCRAPER_CONCURRENCY, len(portals))

    results = await loop.run_in_executor(
        None, lambda: run_scraper(portals, concurrency=concurrency)
    )

    all_posts: List[Post] = []
    for r in results:
        all_posts.extend(r.get("posts", []))

    job.posts_found = sum(r.get("count", 0) for r in results)
    logger.info(f"  Raw: {job.posts_found} articles | Matched: {len(all_posts)} posts")

    if all_posts:
        try:
            ai_results = await engine.analyse_batch([p.content for p in all_posts])
            for post, ai in zip(all_posts, ai_results):
                post.label       = ai.label
                post.confidence  = ai.confidence
                post.risk_score  = ai.risk_score
                post.ai_scores   = ai.scores
                post.analysed_at = datetime.utcnow()
            job.posts_analysed = len(all_posts)
            logger.info(f"  AI done: {len(all_posts)} classified")
        except Exception as exc:
            logger.error(f"  AI failed: {exc}")
            job.error_log.append(f"AI: {exc}")

        try:
            saved = await repo.bulk_upsert(all_posts)
            logger.success(f"  MongoDB: {saved} upserted")
        except Exception as exc:
            logger.error(f"  DB failed: {exc}")
            job.error_log.append(f"DB: {exc}")

    job.status = (
        JobStatus.COMPLETED if not job.error_log else
        JobStatus.PARTIAL   if job.posts_analysed > 0 else
        JobStatus.FAILED
    )
    job.completed_at = datetime.utcnow()
    await repo.update_job(job)

    failed = sum(1 for r in results if r.get("status") == "failed")
    logger.info(
        f"Cycle #{_cycle_number} done | outlets={len(portals)} failed={failed} "
        f"posts={len(all_posts)} status={job.status}"
    )
    _cycle_number += 1


async def _safe_cycle() -> None:
    try:
        await _run_cycle()
    except Exception as exc:
        logger.error(f"Cycle #{_cycle_number} crashed: {exc}")


def start_scheduler() -> None:
    global _scheduler
    logger.info(f"Portal registry:\n{summary()}")
    _scheduler = AsyncIOScheduler(timezone="Asia/Dhaka")
    _scheduler.add_job(
        _safe_cycle,
        trigger="interval",
        minutes=settings.SCRAPER_INTERVAL_MINUTES,
        id="peaceshield_scraper",
        max_instances=1,
        coalesce=True,
        replace_existing=True,
        next_run_time=datetime.now(),
    )
    _scheduler.start()
    logger.info(f"Scheduler running | {settings.SCRAPER_INTERVAL_MINUTES}min intervals | {TOTAL_PORTALS} portals total")


def stop_scheduler() -> None:
    global _scheduler
    if _scheduler and _scheduler.running:
        _scheduler.shutdown(wait=False)
        logger.info("Scheduler stopped.")


def get_cycle_number() -> int:
    return _cycle_number
