"""
app/services/scraper/news_portals.py

94+ News Portal Registry — PeaceShield BD
==========================================
All outlets from the SCRAPER ENGINE v4.0 SITE_SELECTORS,
organised into priority tiers and categories.

Priority levels:
  1 = Critical  — scraped every 30 min
  2 = High      — scraped every 1 hour
  3 = Medium    — scraped every 2 hours
  4 = Low       — scraped every 4 hours

Categories:
  bd_tv         — Bangladesh TV channels
  bd_newspaper  — Bangladesh Bangla newspapers
  bd_english    — Bangladesh English newspapers
  indian_bn     — Indian Bangla outlets
  indian_en     — Indian English outlets
  international — Global English outlets
  asian         — Asia-Pacific outlets
"""

from __future__ import annotations
from typing import List, Dict, Any


# ── Master Portal Registry ────────────────────────────────────────────────

NEWS_PORTALS: List[Dict[str, Any]] = [

    # ══════════════════════════════════════════════════════════════════════
    # BANGLADESH TV CHANNELS  (Priority 1-2)
    # ══════════════════════════════════════════════════════════════════════

    {"name": "Somoy TV",           "website": "somoynews.tv",        "category": "bd_tv",        "priority": 1, "max_articles": 20, "key_person": "Ahmed Jobaer"},
    {"name": "Jamuna TV",          "website": "jamuna.tv",           "category": "bd_tv",        "priority": 1, "max_articles": 20, "key_person": "Fazle Rabbi"},
    {"name": "Channel 24",         "website": "channel24bd.tv",      "category": "bd_tv",        "priority": 1, "max_articles": 20, "key_person": "Nasimul Ahsan"},
    {"name": "Ekattor TV",         "website": "ekattor.tv",          "category": "bd_tv",        "priority": 1, "max_articles": 20, "key_person": "Mozammel Babu"},
    {"name": "Independent TV",     "website": "independent24.com",   "category": "bd_tv",        "priority": 1, "max_articles": 15, "key_person": "—"},
    {"name": "NTV",                "website": "ntvbd.com",           "category": "bd_tv",        "priority": 1, "max_articles": 20, "key_person": "Mostafa Kamal"},
    {"name": "Channel i",          "website": "channelionline.com",  "category": "bd_tv",        "priority": 2, "max_articles": 15, "key_person": "Shykh Seraj"},
    {"name": "ATN News",           "website": "atnnewsltd.com",      "category": "bd_tv",        "priority": 2, "max_articles": 15, "key_person": "Mahfuz Mishu"},
    {"name": "DBC News",           "website": "dbcnews.tv",          "category": "bd_tv",        "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "News24",             "website": "news24bd.tv",         "category": "bd_tv",        "priority": 1, "max_articles": 20, "key_person": "—"},
    {"name": "RTV",                "website": "rtvonline.com",       "category": "bd_tv",        "priority": 1, "max_articles": 20, "key_person": "—"},
    {"name": "BV News",            "website": "bvnews24.com",        "category": "bd_tv",        "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "Ekushey TV",         "website": "ekushey-tv.com",      "category": "bd_tv",        "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Maasranga TV",       "website": "maasranga.tv",        "category": "bd_tv",        "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "BTV",                "website": "btv.gov.bd",          "category": "bd_tv",        "priority": 2, "max_articles": 10, "key_person": "—"},
    {"name": "Boishakhi TV",       "website": "boishakhionline.com", "category": "bd_tv",        "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Desh TV",            "website": "desh.tv",             "category": "bd_tv",        "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Nagorik TV",         "website": "nagorik.tv",          "category": "bd_tv",        "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "Global TV",          "website": "globaltvbd.com",      "category": "bd_tv",        "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "Asian TV",           "website": "asiantvonline.com",   "category": "bd_tv",        "priority": 3, "max_articles": 10, "key_person": "—"},

    # ══════════════════════════════════════════════════════════════════════
    # BANGLADESH NEWSPAPERS — Bangla  (Priority 1-2)
    # ══════════════════════════════════════════════════════════════════════

    {"name": "Prothom Alo",        "website": "prothomalo.com",          "category": "bd_newspaper", "priority": 1, "max_articles": 25, "key_person": "Matiur Rahman"},
    {"name": "BD Pratidin",        "website": "bd-pratidin.com",         "category": "bd_newspaper", "priority": 1, "max_articles": 20, "key_person": "Naem Nizam"},
    {"name": "Jugantor",           "website": "jugantor.com",            "category": "bd_newspaper", "priority": 1, "max_articles": 20, "key_person": "Saiful Alam"},
    {"name": "Kaler Kantho",       "website": "kalerkantho.com",         "category": "bd_newspaper", "priority": 1, "max_articles": 20, "key_person": "Imdat Pehlivan"},
    {"name": "Ittefaq",            "website": "ittefaq.com.bd",          "category": "bd_newspaper", "priority": 1, "max_articles": 20, "key_person": "Anwar Hossain Manju"},
    {"name": "Samakal",            "website": "samakal.com",             "category": "bd_newspaper", "priority": 1, "max_articles": 20, "key_person": "Golam Sarwar"},
    {"name": "Amar Shomoy",        "website": "dainikamadershomoy.com",  "category": "bd_newspaper", "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Janakantha",         "website": "dailyjanakantha.com",     "category": "bd_newspaper", "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Manob Zamin",        "website": "mzamin.com",              "category": "bd_newspaper", "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Naya Diganta",       "website": "dailynayadiganta.com",    "category": "bd_newspaper", "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Bhorer Kagoj",       "website": "bhorerkagoj.com",         "category": "bd_newspaper", "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Daily Inqilab",      "website": "dailyinqilab.com",        "category": "bd_newspaper", "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Jai Jai Din",        "website": "jaijaidinbd.com",         "category": "bd_newspaper", "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Sangbad",            "website": "sangbad.net.bd",          "category": "bd_newspaper", "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "Ajker Patrika",      "website": "ajkerpatrika.com",        "category": "bd_newspaper", "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Kalbela",            "website": "kalbela.com",             "category": "bd_newspaper", "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Bonik Barta",        "website": "bonikbarta.net",          "category": "bd_newspaper", "priority": 2, "max_articles": 10, "key_person": "—"},
    {"name": "Desh Rupantor",      "website": "deshrupantor.com",        "category": "bd_newspaper", "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Alokito Bangladesh", "website": "alokitobangladesh.com",   "category": "bd_newspaper", "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "Dainik Bangla",      "website": "dainikbangla.com.bd",     "category": "bd_newspaper", "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Jago News",          "website": "jagonews24.com",          "category": "bd_newspaper", "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Bangla Tribune",     "website": "banglatribune.com",       "category": "bd_newspaper", "priority": 1, "max_articles": 20, "key_person": "—"},
    {"name": "JJ Din",             "website": "jjdin.com",               "category": "bd_newspaper", "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "Amar Desh",          "website": "amar-desh24.com",         "category": "bd_newspaper", "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "Bangla News 24",     "website": "bangla.bdnews24.com",     "category": "bd_newspaper", "priority": 1, "max_articles": 20, "key_person": "—"},

    # ══════════════════════════════════════════════════════════════════════
    # BANGLADESH ENGLISH NEWSPAPERS  (Priority 1-2)
    # ══════════════════════════════════════════════════════════════════════

    {"name": "The Daily Star",     "website": "thedailystar.net",    "category": "bd_english",   "priority": 1, "max_articles": 25, "key_person": "Mahfuz Anam"},
    {"name": "Dhaka Tribune",      "website": "dhakatribune.com",    "category": "bd_english",   "priority": 1, "max_articles": 20, "key_person": "Zafar Sobhan"},
    {"name": "TBS News",           "website": "tbsnews.net",         "category": "bd_english",   "priority": 1, "max_articles": 20, "key_person": "—"},
    {"name": "The Observer BD",    "website": "observerbd.com",      "category": "bd_english",   "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "BD News 24 EN",      "website": "bdnews24.com",        "category": "bd_english",   "priority": 1, "max_articles": 20, "key_person": "Toufique Imrose Khalidi"},
    {"name": "Financial Express",  "website": "thefinancialexpress.com.bd", "category": "bd_english", "priority": 2, "max_articles": 10, "key_person": "—"},
    {"name": "New Age BD",         "website": "newagebd.net",        "category": "bd_english",   "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Prothomalo EN",      "website": "en.prothomalo.com",   "category": "bd_english",   "priority": 2, "max_articles": 15, "key_person": "—"},

    # ══════════════════════════════════════════════════════════════════════
    # INDIAN BANGLA OUTLETS  (Priority 2-3)
    # ══════════════════════════════════════════════════════════════════════

    {"name": "Ananda Bazar",       "website": "anandabazar.com",     "category": "indian_bn",    "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Sangbad Pratidin",   "website": "sangbadpratidin.in",  "category": "indian_bn",    "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "ABP Ananda",         "website": "bengali.abplive.com", "category": "indian_bn",    "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Zee 24 Ghanta",      "website": "zee24ghanta.com",     "category": "indian_bn",    "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Ei Samay",           "website": "eisamay.com",         "category": "indian_bn",    "priority": 2, "max_articles": 10, "key_person": "—"},
    {"name": "Bartaman Patrika",   "website": "bartamanpatrika.com", "category": "indian_bn",    "priority": 3, "max_articles": 10, "key_person": "—"},

    # ══════════════════════════════════════════════════════════════════════
    # INDIAN ENGLISH  (Priority 2-3)
    # ══════════════════════════════════════════════════════════════════════

    {"name": "Times of India",     "website": "timesofindia.indiatimes.com", "category": "indian_en", "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "NDTV",               "website": "ndtv.com",            "category": "indian_en",    "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Hindustan Times",    "website": "hindustantimes.com",  "category": "indian_en",    "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "The Hindu",          "website": "thehindu.com",        "category": "indian_en",    "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Indian Express",     "website": "indianexpress.com",   "category": "indian_en",    "priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Aaj Tak",            "website": "aajtak.in",           "category": "indian_en",    "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "India Today",        "website": "indiatoday.in",       "category": "indian_en",    "priority": 2, "max_articles": 10, "key_person": "—"},
    {"name": "Economic Times",     "website": "economictimes.indiatimes.com", "category": "indian_en", "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "News18",             "website": "news18.com",          "category": "indian_en",    "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "LiveMint",           "website": "livemint.com",        "category": "indian_en",    "priority": 3, "max_articles": 10, "key_person": "—"},

    # ══════════════════════════════════════════════════════════════════════
    # INTERNATIONAL  (Priority 1-3)
    # ══════════════════════════════════════════════════════════════════════

    {"name": "Al Jazeera",         "website": "aljazeera.com",       "category": "international","priority": 1, "max_articles": 20, "key_person": "—"},
    {"name": "BBC News",           "website": "bbc.com",             "category": "international","priority": 1, "max_articles": 20, "key_person": "—"},
    {"name": "The Guardian",       "website": "theguardian.com",     "category": "international","priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "Reuters",            "website": "reuters.com",         "category": "international","priority": 1, "max_articles": 20, "key_person": "—"},
    {"name": "AP News",            "website": "apnews.com",          "category": "international","priority": 1, "max_articles": 20, "key_person": "—"},
    {"name": "DW",                 "website": "dw.com",              "category": "international","priority": 2, "max_articles": 15, "key_person": "—"},
    {"name": "VOA Bangla",         "website": "voabangla.com",       "category": "international","priority": 1, "max_articles": 15, "key_person": "—"},

    # ══════════════════════════════════════════════════════════════════════
    # ASIAN / REGIONAL  (Priority 2-3)
    # ══════════════════════════════════════════════════════════════════════

    {"name": "Nikkei Asia",        "website": "asia.nikkei.com",     "category": "asian",        "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "SCMP",               "website": "scmp.com",            "category": "asian",        "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "CNA",                "website": "channelnewsasia.com", "category": "asian",        "priority": 2, "max_articles": 10, "key_person": "—"},
    {"name": "Straits Times",      "website": "straitstimes.com",    "category": "asian",        "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "Asia Times",         "website": "asiatimes.com",       "category": "asian",        "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "Japan Times",        "website": "japantimes.co.jp",    "category": "asian",        "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "Bangkok Post",       "website": "bangkokpost.com",     "category": "asian",        "priority": 3, "max_articles": 10, "key_person": "—"},
    {"name": "Asian News Network", "website": "asianews.network",    "category": "asian",        "priority": 3, "max_articles": 10, "key_person": "—"},
]


# ── Derived helpers ───────────────────────────────────────────────────────

TOTAL_PORTALS = len(NEWS_PORTALS)

# Priority buckets for scheduler rotation
PRIORITY_1: List[Dict] = [p for p in NEWS_PORTALS if p["priority"] == 1]   # every 30 min
PRIORITY_2: List[Dict] = [p for p in NEWS_PORTALS if p["priority"] == 2]   # every 60 min
PRIORITY_3: List[Dict] = [p for p in NEWS_PORTALS if p["priority"] == 3]   # every 2 hours
PRIORITY_4: List[Dict] = [p for p in NEWS_PORTALS if p["priority"] == 4]   # every 4 hours

# Category buckets
BD_PORTALS    = [p for p in NEWS_PORTALS if p["category"] in ("bd_tv", "bd_newspaper", "bd_english")]
INDIAN_PORTALS = [p for p in NEWS_PORTALS if p["category"] in ("indian_bn", "indian_en")]
INTL_PORTALS  = [p for p in NEWS_PORTALS if p["category"] in ("international", "asian")]


def get_portals_by_priority(priority: int) -> List[Dict]:
    return [p for p in NEWS_PORTALS if p["priority"] == priority]


def get_portals_by_category(category: str) -> List[Dict]:
    return [p for p in NEWS_PORTALS if p["category"] == category]


def get_portals_for_cycle(cycle_number: int) -> List[Dict]:
    """
    Smart rotation: returns the correct subset for a given cycle tick.

    Cycle logic:
      Every tick   → P1 (critical, always)
      Even tick    → P2 (high, every other)
      Div-by-4     → P3 (medium, every 4th)
      Div-by-8     → P4 (low, every 8th)

    With 30-min intervals:
      P1 = every 30 min
      P2 = every 60 min
      P3 = every 2 hours
      P4 = every 4 hours
    """
    portals = list(PRIORITY_1)                         # always include P1
    if cycle_number % 2 == 0:
        portals += PRIORITY_2
    if cycle_number % 4 == 0:
        portals += PRIORITY_3
    if cycle_number % 8 == 0:
        portals += PRIORITY_4
    return portals


def summary() -> str:
    lines = [
        f"Total portals : {TOTAL_PORTALS}",
        f"Priority 1    : {len(PRIORITY_1)}  (every 30 min)",
        f"Priority 2    : {len(PRIORITY_2)}  (every 60 min)",
        f"Priority 3    : {len(PRIORITY_3)}  (every 2 hours)",
        f"BD portals    : {len(BD_PORTALS)}",
        f"Indian portals: {len(INDIAN_PORTALS)}",
        f"Intl portals  : {len(INTL_PORTALS)}",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    print(summary())
    print(f"\nCycle 0 (P1+P2+P3+P4): {len(get_portals_for_cycle(0))} portals")
    print(f"Cycle 1 (P1 only)     : {len(get_portals_for_cycle(1))} portals")
    print(f"Cycle 2 (P1+P2)       : {len(get_portals_for_cycle(2))} portals")
