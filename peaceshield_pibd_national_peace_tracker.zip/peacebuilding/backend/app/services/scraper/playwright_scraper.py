"""
app/services/scraper/playwright_scraper.py

Concurrent Playwright Scraper
==============================
• Targets Facebook public pages, Twitter/X, Bangla news sites
• Keyword-based filtering: নির্বাচন, ভোট, দাঙ্গা, সংঘাত, etc.
• asyncio.Semaphore limits concurrency to avoid VPS overload
• Each scraped post → AI analysis → MongoDB upsert
"""

import asyncio
import re
from datetime import datetime
from typing import List, Optional

from playwright.async_api import (
    async_playwright,
    Browser,
    Page,
    TimeoutError as PWTimeout,
)
from loguru import logger

from app.core.config import settings
from app.models.schemas import Post, PostSource, ScraperJob, JobStatus


# ── Bangla/English keyword taxonomy ───────────────────────────────────────
SCRAPE_KEYWORDS = [
    # Elections & politics
    "নির্বাচন", "ভোট", "রাজনীতি", "আওয়ামী লীগ", "বিএনপি",
    # Conflict & violence
    "দাঙ্গা", "সংঘাত", "সহিংসতা", "হামলা", "হত্যা",
    # Misinformation markers
    "গুজব", "মিথ্যা", "ষড়যন্ত্র",
    # Hate speech targets
    "হিন্দু", "মুসলিম", "সংখ্যালঘু",
    # English equivalents
    "election", "vote", "riot", "attack", "rumour",
]

# News sources to scrape (publicly accessible)
SCRAPE_TARGETS = [
    {"url": "https://www.prothomalo.com/", "source": PostSource.NEWS, "name": "Prothom Alo"},
    {"url": "https://www.bdnews24.com/", "source": PostSource.NEWS, "name": "BD News 24"},
    {"url": "https://www.thedailystar.net/bangla", "source": PostSource.NEWS, "name": "Daily Star Bangla"},
    {"url": "https://www.kalerkantho.com/", "source": PostSource.NEWS, "name": "Kaler Kantho"},
    {"url": "https://samakal.com/", "source": PostSource.NEWS, "name": "Samakal"},
]


class PlaywrightScraper:
    """
    Manages a single reusable Chromium browser instance.
    Each scrape task gets its own isolated Page.
    """

    def __init__(self):
        self._browser: Optional[Browser] = None
        self._semaphore = asyncio.Semaphore(settings.SCRAPER_CONCURRENCY)

    async def _get_browser(self) -> Browser:
        if self._browser is None or not self._browser.is_connected():
            pw = await async_playwright().start()
            self._browser = await pw.chromium.launch(
                headless=True,
                args=[
                    "--no-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-gpu",
                    "--disable-extensions",
                    "--disable-background-networking",
                    "--memory-pressure-off",
                ],
            )
        return self._browser

    async def _configure_page(self, page: Page) -> None:
        """Block images, fonts, media — only fetch HTML/JS/CSS."""
        await page.set_extra_http_headers({
            "User-Agent": (
                "Mozilla/5.0 (compatible; PeaceShieldBot/1.0; "
                "+https://peaceshield.bd/bot)"
            ),
            "Accept-Language": "bn-BD,bn;q=0.9,en;q=0.8",
        })
        await page.route(
            "**/*.{png,jpg,jpeg,gif,webp,svg,mp4,mp3,woff,woff2,ttf,eot}",
            lambda route: route.abort(),
        )

    async def scrape_site(
        self, target: dict, keywords: List[str]
    ) -> List[Post]:
        """Scrape one news site, extract article previews matching keywords."""
        browser = await self._get_browser()
        posts: List[Post] = []

        async with self._semaphore:
            page = await browser.new_page()
            await self._configure_page(page)

            try:
                logger.info(f"Scraping: {target['name']} → {target['url']}")
                await page.goto(
                    target["url"],
                    wait_until="domcontentloaded",
                    timeout=settings.SCRAPER_TIMEOUT_MS,
                )

                # Extract all visible text blocks from article/headline elements
                elements = await page.query_selector_all(
                    "h1, h2, h3, p, .headline, .title, article, .news-title, "
                    ".article-title, .story-title"
                )

                for el in elements[:200]:    # cap per page to avoid runaway
                    try:
                        text = (await el.inner_text()).strip()
                        if len(text) < 15:
                            continue

                        matched = self._keyword_match(text, keywords)
                        if not matched:
                            continue

                        # Try to get parent link as source_url
                        link_el = await el.query_selector("a")
                        if not link_el:
                            link_el = await page.query_selector(f"a:has-text('{text[:20]}')")

                        src_url = None
                        if link_el:
                            src_url = await link_el.get_attribute("href")
                            if src_url and not src_url.startswith("http"):
                                base = target["url"].rstrip("/")
                                src_url = f"{base}{src_url}"

                        post = Post(
                            content=text,
                            source=target["source"],
                            source_url=src_url,
                            keywords_matched=matched,
                            metadata={"site": target["name"]},
                        )
                        posts.append(post)

                    except Exception:
                        continue

                logger.info(f"[{target['name']}] Found {len(posts)} keyword-matched items.")

            except PWTimeout:
                logger.warning(f"Timeout on {target['url']}")
            except Exception as exc:
                logger.error(f"Error scraping {target['name']}: {exc}")
            finally:
                await page.close()

        return posts

    async def run_full_cycle(
        self, keywords: List[str], job: "ScraperJob", repo
    ) -> ScraperJob:
        """
        Full concurrent scrape cycle across all SCRAPE_TARGETS.
        Followed by batch AI analysis and MongoDB upsert.
        """
        from app.services.ai.engine import get_engine
        engine = get_engine()

        job.status = JobStatus.RUNNING
        await repo.update_job(job)

        # Concurrent scraping
        tasks = [self.scrape_site(target, keywords) for target in SCRAPE_TARGETS]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        all_posts: List[Post] = []
        for result in results:
            if isinstance(result, list):
                all_posts.extend(result)
            elif isinstance(result, Exception):
                job.error_log.append(str(result))

        job.posts_found = len(all_posts)
        logger.info(f"Total raw posts: {len(all_posts)}")

        # Batch AI analysis
        if all_posts:
            texts = [p.content for p in all_posts]
            try:
                ai_results = await engine.analyse_batch(texts)
                for post, ai in zip(all_posts, ai_results):
                    post.label = ai.label
                    post.confidence = ai.confidence
                    post.risk_score = ai.risk_score
                    post.ai_scores = ai.scores
                    post.analysed_at = datetime.utcnow()
                job.posts_analysed = len(all_posts)
            except Exception as exc:
                logger.error(f"Batch AI analysis failed: {exc}")
                job.error_log.append(f"AI error: {exc}")

            # Save to MongoDB
            saved = await repo.bulk_upsert(all_posts)
            logger.success(f"Saved {saved} posts to MongoDB.")

        job.status = JobStatus.COMPLETED if not job.error_log else JobStatus.FAILED
        job.completed_at = datetime.utcnow()
        await repo.update_job(job)

        return job

    @staticmethod
    def _keyword_match(text: str, keywords: List[str]) -> List[str]:
        """Return list of matched keywords found in text."""
        lower = text.lower()
        return [kw for kw in keywords if kw.lower() in lower]

    async def close(self) -> None:
        if self._browser:
            await self._browser.close()
            self._browser = None


# ── Module-level singleton ─────────────────────────────────────────────────
_scraper: Optional[PlaywrightScraper] = None


def get_scraper() -> PlaywrightScraper:
    global _scraper
    if _scraper is None:
        _scraper = PlaywrightScraper()
    return _scraper
