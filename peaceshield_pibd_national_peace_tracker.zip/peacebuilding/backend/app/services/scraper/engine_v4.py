"""
app/services/scraper/engine_v4.py

SCRAPER ENGINE v4.0 — ULTRA ADVANCED
PeaceShield BD Integration
=====================================
Unchanged logic from the original engine.
Added:
  • PeaceShield hate-keyword pre-filter (fast match before AI)
  • Article → Post conversion for MongoDB storage
  • Structured logging via loguru
  • Integration with news_portals.py registry

Tier stack (per outlet, auto-fallback):
  TIER 1  aiohttp + BeautifulSoup   (lightweight / fast)
  TIER 2  Playwright async          (JS-rendered pages)
  TIER 3  Playwright stealth        (anti-bot bypass)
  TIER 4  Google News RSS           (reliable fallback)
  TIER 5  Direct RSS/Atom feed      (last resort)
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import random
import re
import time
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin, urlparse, quote_plus

from loguru import logger

# ── Optional dependency guards ─────────────────────────────────────────────
try:
    import aiohttp
    HAS_AIOHTTP = True
except ImportError:
    HAS_AIOHTTP = False
    logger.warning("aiohttp not installed — Tier 1 disabled")

try:
    from bs4 import BeautifulSoup
    HAS_BS4 = True
except ImportError:
    HAS_BS4 = False
    logger.warning("beautifulsoup4 not installed — HTML parsing degraded")

try:
    import feedparser
    HAS_FEEDPARSER = True
except ImportError:
    HAS_FEEDPARSER = False

try:
    from playwright.async_api import async_playwright
    HAS_PLAYWRIGHT = True
except ImportError:
    HAS_PLAYWRIGHT = False
    logger.warning("playwright not installed — Tiers 2/3 disabled")

# ── Local imports ──────────────────────────────────────────────────────────
from app.services.scraper.site_selectors import SITE_SELECTORS, _GENERIC_CFG
from app.models.schemas import Post, PostSource, HateLabel

# ══════════════════════════════════════════════════════════════════════════
# PEACE/HATE KEYWORD PRE-FILTER
# Fast string match before sending to Bangla-BERT.
# Anything matching → queued for AI analysis.
# Non-matching → stored as Neutral immediately (saves VPS RAM).
# ══════════════════════════════════════════════════════════════════════════

PEACE_KEYWORDS = [
    # Conflict / violence
    "দাঙ্গা", "সংঘাত", "সহিংসতা", "হামলা", "হত্যা", "গুলি",
    "বোমা", "আগুন", "লুটপাট", "ধ্বংস", "জঙ্গি", "সন্ত্রাস",
    # Hate targets
    "সংখ্যালঘু", "হিন্দু বিরোধী", "মুসলিম বিরোধী", "ধর্মীয় উস্কানি",
    # Misinformation
    "গুজব", "ভুয়া", "মিথ্যা", "ষড়যন্ত্র", "অপপ্রচার",
    # Elections
    "নির্বাচন", "ভোট", "কারচুপি", "রিগিং",
    # English equivalents
    "riot", "attack", "violence", "hate", "rumour", "fake news",
    "minority", "communal", "terror", "bomb", "arson",
    "election fraud", "vote rigging",
]

_KW_SET = {k.lower() for k in PEACE_KEYWORDS}


def _matches_peace_keywords(text: str) -> List[str]:
    """Return list of matched keywords. Empty list = not relevant."""
    lower = text.lower()
    return [kw for kw in _KW_SET if kw in lower]


# ══════════════════════════════════════════════════════════════════════════
# ARTICLE DATA STRUCTURE
# ══════════════════════════════════════════════════════════════════════════

def _empty_article(url: str = "", title: str = "") -> dict:
    return {
        "title":        title,
        "url":          url,
        "summary":      "",
        "full_text":    "",
        "published_at": "",
        "author":       "",
        "image_url":    "",
        "tags":         [],
        "word_count":   0,
        "scraped_at":   datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
    }


# ══════════════════════════════════════════════════════════════════════════
# USER AGENTS
# ══════════════════════════════════════════════════════════════════════════

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
]

def _ua() -> str:
    return random.choice(USER_AGENTS)


# ══════════════════════════════════════════════════════════════════════════
# HTML UTILITIES
# ══════════════════════════════════════════════════════════════════════════

def _clean(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r'[\r\n\t]+', ' ', text)
    text = re.sub(r'\s{2,}', ' ', text)
    return text.strip()[:500]


def _clean_body(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r'[\r\n\t]+', ' ', text)
    text = re.sub(r'\s{2,}', ' ', text)
    return text.strip()


def _get_domain(outlet: dict) -> str:
    site = outlet.get("website", "")
    if not site.startswith("http"):
        site = "https://" + site
    return urlparse(site).netloc.lstrip("www.")


def _build_url(outlet: dict) -> str:
    site = outlet.get("website", "")
    if not site.startswith("http"):
        return "https://" + site
    return site


def _abs_url(href: str, base: str) -> str:
    if not href:
        return ""
    href = href.strip()
    if href.startswith("http"):
        return href
    return urljoin(base, href)


def _parse_html_articles(html: str, cfg: dict, base_url: str) -> list:
    if not HAS_BS4:
        return []
    soup = BeautifulSoup(html, "html.parser")
    results, seen_urls = [], set()

    for sel in cfg.get("link_sel", []):
        try:
            for el in soup.select(sel):
                title = _clean(el.get_text())
                href  = el.get("href", "")
                if not href:
                    parent = el.find_parent("a")
                    if parent:
                        href = parent.get("href", "")
                url = _abs_url(href, base_url)
                if title and len(title) > 8 and url and url not in seen_urls:
                    seen_urls.add(url)
                    results.append({"title": title, "url": url})
            if len(results) >= 5:
                break
        except Exception:
            continue

    if not results:
        for tag in (soup.find_all(["h2", "h3"]) if soup else []):
            a = tag.find("a", href=True)
            if a:
                title = _clean(a.get_text())
                url   = _abs_url(a["href"], base_url)
                if title and len(title) > 8 and url and url not in seen_urls:
                    seen_urls.add(url)
                    results.append({"title": title, "url": url})

    return results[:30]


def _extract_article_content(html: str, cfg: dict, article_url: str) -> dict:
    if not HAS_BS4:
        return {}
    soup = BeautifulSoup(html, "html.parser")

    # Full body
    full_text = ""
    for sel in cfg.get("content_sel", []):
        try:
            paras = soup.select(sel)
            if paras:
                full_text = " ".join(_clean(p.get_text()) for p in paras if _clean(p.get_text()))
                if len(full_text) > 100:
                    break
        except Exception:
            continue

    if len(full_text) < 80:
        art = soup.find("article")
        if art:
            paras = art.find_all("p")
            full_text = " ".join(_clean(p.get_text()) for p in paras if len(_clean(p.get_text())) > 15)

    # Summary
    summary = ""
    for sel in cfg.get("summary_sel", []):
        try:
            el = soup.select_one(sel)
            if el:
                summary = _clean(el.get_text())
                if len(summary) > 20:
                    break
        except Exception:
            continue
    if not summary and full_text:
        summary = full_text[:250].rsplit(" ", 1)[0] + "…"

    # Author
    author = ""
    for sel in cfg.get("author_sel", []):
        try:
            el = soup.select_one(sel)
            if el:
                author = _clean(el.get_text())
                if author and len(author) > 1:
                    break
        except Exception:
            continue

    # Date
    published_at = ""
    for sel in cfg.get("date_sel", []):
        try:
            el = soup.select_one(sel)
            if el:
                published_at = (
                    el.get("datetime", "") or el.get("content", "") or _clean(el.get_text())
                )
                if published_at:
                    break
        except Exception:
            continue

    # JSON-LD fallback
    if not published_at:
        for script in soup.find_all("script", type="application/ld+json"):
            try:
                data = json.loads(script.string or "")
                if isinstance(data, list):
                    data = data[0]
                published_at = data.get("datePublished", "") or data.get("dateModified", "")
                if not author:
                    auth = data.get("author", {})
                    if isinstance(auth, dict):
                        author = auth.get("name", "")
                    elif isinstance(auth, list) and auth:
                        author = auth[0].get("name", "")
                if published_at:
                    break
            except Exception:
                continue

    # Image
    image_url = ""
    for sel in cfg.get("image_sel", []):
        try:
            el = soup.select_one(sel)
            if el:
                image_url = el.get("src", "") or el.get("data-src", "") or el.get("data-lazy-src", "")
                if image_url:
                    image_url = _abs_url(image_url, article_url)
                    break
        except Exception:
            continue

    # Tags
    tags = []
    try:
        meta_kw = soup.find("meta", attrs={"name": "keywords"})
        if meta_kw:
            tags = [t.strip() for t in meta_kw.get("content", "").split(",") if t.strip()][:8]
    except Exception:
        pass

    return {
        "full_text":    _clean_body(full_text)[:8000],
        "summary":      summary[:500],
        "author":       author[:100],
        "published_at": published_at[:50],
        "image_url":    image_url[:500],
        "tags":         tags,
        "word_count":   len(full_text.split()) if full_text else 0,
    }


# ══════════════════════════════════════════════════════════════════════════
# TIER FETCHERS
# ══════════════════════════════════════════════════════════════════════════

async def _fetch_html_aiohttp(url: str, session) -> Optional[str]:
    headers = {
        "User-Agent":      _ua(),
        "Accept":          "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9,bn;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
        "Cache-Control":   "no-cache",
        "Connection":      "keep-alive",
    }
    try:
        async with session.get(
            url, headers=headers,
            timeout=aiohttp.ClientTimeout(total=18),
            allow_redirects=True, ssl=False
        ) as resp:
            if resp.status == 200:
                return await resp.text(errors="replace")
    except Exception as e:
        logger.debug(f"aiohttp {url}: {e}")
    return None


async def _fetch_html_playwright(url: str, browser) -> Optional[str]:
    if not browser:
        return None
    page = None
    try:
        page = await browser.new_page(
            user_agent=_ua(),
            viewport={"width": 1366, "height": 768},
            extra_http_headers={"Accept-Language": "en-US,en;q=0.9,bn;q=0.8"},
        )
        await page.goto(url, timeout=28000, wait_until="domcontentloaded")
        await asyncio.sleep(1.8)
        return await page.content()
    except Exception as e:
        logger.debug(f"Playwright {url}: {e}")
        return None
    finally:
        if page:
            try:
                await page.close()
            except Exception:
                pass


async def _fetch_html_stealth(url: str, browser) -> Optional[str]:
    if not browser:
        return None
    context = None
    try:
        context = await browser.new_context(
            user_agent=_ua(),
            viewport={"width": 1920, "height": 1080},
            locale="en-US",
            timezone_id="Asia/Dhaka",
            extra_http_headers={
                "Accept-Language":    "en-US,en;q=0.9,bn;q=0.8",
                "sec-ch-ua":          '"Not A(Brand";v="99", "Google Chrome";v="121"',
                "sec-ch-ua-mobile":   "?0",
                "sec-ch-ua-platform": '"Windows"',
                "Sec-Fetch-Dest":     "document",
                "Sec-Fetch-Mode":     "navigate",
                "Sec-Fetch-Site":     "none",
            }
        )
        await context.add_init_script("""
            Object.defineProperty(navigator, 'webdriver',          { get: () => undefined });
            Object.defineProperty(navigator, 'plugins',            { get: () => [1, 2, 3, 4, 5] });
            Object.defineProperty(navigator, 'languages',          { get: () => ['en-US', 'en', 'bn'] });
            Object.defineProperty(navigator, 'platform',           { get: () => 'Win32' });
            window.chrome = { runtime: {}, loadTimes: function(){}, csi: function(){} };
            Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 8 });
            Object.defineProperty(screen,    'colorDepth',          { get: () => 24 });
        """)
        page = await context.new_page()
        await page.goto(url, timeout=32000, wait_until="domcontentloaded")
        await page.evaluate("window.scrollTo(0, Math.random() * 800 + 100)")
        await asyncio.sleep(random.uniform(1.5, 3.0))
        return await page.content()
    except Exception as e:
        logger.debug(f"Stealth {url}: {e}")
        return None
    finally:
        if context:
            try:
                await context.close()
            except Exception:
                pass


async def _fetch_html(url: str, tier: int, session, browser) -> Optional[str]:
    if tier == 1:
        return await _fetch_html_aiohttp(url, session)
    elif tier == 2:
        html = await _fetch_html_playwright(url, browser)
        return html or await _fetch_html_aiohttp(url, session)
    elif tier == 3:
        html = await _fetch_html_stealth(url, browser)
        if not html:
            html = await _fetch_html_playwright(url, browser)
        return html or await _fetch_html_aiohttp(url, session)
    return None


async def _gnews_rss(domain: str, session) -> list:
    if not HAS_AIOHTTP:
        return []
    url = f"https://news.google.com/rss/search?q=site:{domain}&hl=en&gl=BD&ceid=BD:en"
    try:
        async with session.get(
            url, headers={"User-Agent": _ua()},
            timeout=aiohttp.ClientTimeout(total=12), ssl=False
        ) as resp:
            if resp.status == 200:
                return _parse_rss_to_stubs(await resp.text(errors="replace"))
    except Exception as e:
        logger.debug(f"GNews {domain}: {e}")
    return []


async def _direct_rss(rss_url: str, session) -> list:
    if not rss_url or not HAS_AIOHTTP:
        return []
    try:
        async with session.get(
            rss_url, headers={"User-Agent": _ua()},
            timeout=aiohttp.ClientTimeout(total=12), ssl=False
        ) as resp:
            if resp.status == 200:
                return _parse_rss_to_stubs(await resp.text(errors="replace"))
    except Exception as e:
        logger.debug(f"RSS {rss_url}: {e}")
    return []


def _parse_rss_to_stubs(content: str) -> list:
    stubs = []
    if HAS_FEEDPARSER:
        try:
            feed = feedparser.parse(content)
            for entry in feed.entries[:30]:
                title = _clean(entry.get("title", ""))
                url   = entry.get("link", "")
                summ  = _clean(
                    BeautifulSoup(entry.get("summary", ""), "html.parser").get_text()
                    if HAS_BS4 else entry.get("summary", "")
                )
                pub = entry.get("published", "") or entry.get("updated", "")
                if title and len(title) > 8:
                    stubs.append({
                        "title":        title,
                        "url":          url,
                        "summary":      summ[:400],
                        "published_at": pub,
                        "full_text":    summ,
                        "author":       "",
                        "image_url":    "",
                        "tags":         [],
                        "word_count":   len(summ.split()),
                        "scraped_at":   datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
                        "source":       "rss",
                    })
            if stubs:
                return stubs
        except Exception:
            pass

    # Regex fallback
    title_re = re.compile(r'<title[^>]*>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>', re.DOTALL)
    link_re  = re.compile(r'<link[^>]*>([^<]+)</link>|<link[^>]+href=["\']([^"\']+)["\']', re.DOTALL)
    desc_re  = re.compile(r'<description[^>]*>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</description>', re.DOTALL)

    titles = title_re.findall(content)[1:]
    links  = [m[0] or m[1] for m in link_re.findall(content)]
    descs  = desc_re.findall(content)[1:]

    for i, raw_title in enumerate(titles[:30]):
        title = _clean(re.sub(r'<[^>]+>', '', raw_title))
        url   = links[i + 1].strip() if i + 1 < len(links) else ""
        summ  = _clean(re.sub(r'<[^>]+>', '', descs[i])) if i < len(descs) else ""
        if title and len(title) > 8:
            stubs.append({
                "title":        title,
                "url":          url,
                "summary":      summ[:400],
                "published_at": "",
                "full_text":    summ,
                "author":       "",
                "image_url":    "",
                "tags":         [],
                "word_count":   len(summ.split()),
                "scraped_at":   datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
                "source":       "rss",
            })
    return stubs


async def _fetch_article(stub: dict, cfg: dict, session, browser, art_tier: int) -> dict:
    url = stub.get("url", "")
    if not url or not url.startswith("http"):
        return {**_empty_article(url, stub.get("title", "")), **stub}

    html = await _fetch_html(url, art_tier, session, browser)
    if not html:
        return {**_empty_article(url, stub.get("title", "")), **stub}

    extracted = _extract_article_content(html, cfg, url)
    return {
        "title":        stub.get("title", ""),
        "url":          url,
        "summary":      extracted.get("summary") or stub.get("summary", ""),
        "full_text":    extracted.get("full_text", ""),
        "published_at": extracted.get("published_at") or stub.get("published_at", ""),
        "author":       extracted.get("author", ""),
        "image_url":    extracted.get("image_url", ""),
        "tags":         extracted.get("tags", []),
        "word_count":   extracted.get("word_count", 0),
        "scraped_at":   datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
        "source":       stub.get("source", "scraped"),
    }


# ══════════════════════════════════════════════════════════════════════════
# ARTICLE → POST CONVERTER  (PeaceShield schema)
# ══════════════════════════════════════════════════════════════════════════

_SOURCE_MAP = {
    "bd_tv":        PostSource.NEWS,
    "bd_newspaper": PostSource.NEWS,
    "bd_english":   PostSource.NEWS,
    "indian_bn":    PostSource.NEWS,
    "indian_en":    PostSource.NEWS,
    "international":PostSource.NEWS,
    "asian":        PostSource.NEWS,
}


def article_to_post(article: dict, outlet: dict) -> Optional[Post]:
    """
    Convert a scraped article dict → Post schema for MongoDB.
    Only articles that match peace/hate keywords are returned.
    Non-relevant articles are skipped (return None).
    """
    content = f"{article.get('title', '')} {article.get('summary', '')} {article.get('full_text', '')}"
    matched_kws = _matches_peace_keywords(content)

    # Skip completely irrelevant articles (saves RAM + AI calls)
    if not matched_kws:
        return None

    category = outlet.get("category", "general")
    source   = _SOURCE_MAP.get(category, PostSource.NEWS)

    return Post(
        id=str(uuid.uuid4()),
        content=f"{article['title']}\n\n{article.get('summary', '')}".strip(),
        source=source,
        source_url=article.get("url"),
        author=article.get("author"),
        keywords_matched=matched_kws,
        metadata={
            "outlet_name":  outlet.get("name"),
            "outlet_domain":outlet.get("website"),
            "category":     category,
            "full_text":    article.get("full_text", "")[:3000],
            "image_url":    article.get("image_url", ""),
            "tags":         article.get("tags", []),
            "published_at": article.get("published_at", ""),
            "word_count":   article.get("word_count", 0),
        },
    )


# ══════════════════════════════════════════════════════════════════════════
# SINGLE OUTLET SCRAPER
# ══════════════════════════════════════════════════════════════════════════

async def _scrape_one(outlet: dict, session, browser, semaphore: asyncio.Semaphore) -> dict:
    async with semaphore:
        domain   = _get_domain(outlet)
        base_url = _build_url(outlet)
        name     = outlet.get("name", domain)
        start    = time.time()

        cfg      = SITE_SELECTORS.get(domain, _GENERIC_CFG)
        rss_url  = cfg.get("rss")
        tier     = cfg.get("tier", 1)
        art_tier = cfg.get("article_tier", 1)
        max_arts = outlet.get("max_articles", 15)

        logger.info(f"► {name} ({domain})  tier={tier}  art_tier={art_tier}")

        article_stubs, used_tier = [], "Failed"

        # Step 1: get stubs
        html = await _fetch_html(base_url, tier, session, browser)
        if html:
            stubs = _parse_html_articles(html, cfg, base_url)
            if stubs:
                article_stubs = stubs
                used_tier = {1: "T1-aiohttp", 2: "T2-Playwright", 3: "T3-Stealth"}.get(tier, "T1-aiohttp")

        if not article_stubs and rss_url:
            rss_stubs = await _direct_rss(rss_url, session)
            if rss_stubs:
                article_stubs = rss_stubs
                used_tier = "T5-DirectRSS"

        if not article_stubs:
            gnews_stubs = await _gnews_rss(domain, session)
            if gnews_stubs:
                article_stubs = gnews_stubs
                used_tier = "T4-GNewsRSS"

        # Step 2: fetch full article content
        articles = []
        if article_stubs:
            fetch_tasks = []
            for stub in article_stubs[:max_arts]:
                if stub.get("source") == "rss" and stub.get("full_text"):
                    if stub.get("url", "").startswith("http"):
                        fetch_tasks.append(_fetch_article(stub, cfg, session, browser, art_tier))
                    else:
                        articles.append(stub)
                else:
                    fetch_tasks.append(_fetch_article(stub, cfg, session, browser, art_tier))

            for i in range(0, len(fetch_tasks), 3):
                batch   = fetch_tasks[i:i + 3]
                results = await asyncio.gather(*batch, return_exceptions=True)
                for r in results:
                    if isinstance(r, dict):
                        articles.append(r)
                if i + 3 < len(fetch_tasks):
                    await asyncio.sleep(0.3)

        # Deduplicate articles
        seen, unique = set(), []
        for a in articles:
            key = re.sub(r'\W+', '', a.get("title", "").lower())[:60]
            if key and key not in seen:
                seen.add(key)
                unique.append(a)
        articles = unique

        # Convert to Post objects (keyword-filtered)
        posts = []
        for art in articles:
            post = article_to_post(art, outlet)
            if post:
                posts.append(post)

        elapsed = round(time.time() - start, 2)
        status  = "success" if articles else "failed"

        if articles:
            logger.info(f"  ✅ {name}: {len(articles)} arts → {len(posts)} relevant posts | {used_tier} | {elapsed}s")
        else:
            logger.warning(f"  ❌ {name}: failed | {elapsed}s")

        return {
            "name":         name,
            "website":      domain,
            "url":          base_url,
            "category":     outlet.get("category", "general"),
            "priority":     outlet.get("priority", 3),
            "status":       status,
            "tier":         used_tier,
            "articles":     articles,
            "posts":        posts,               # ← Post objects ready for MongoDB
            "count":        len(articles),
            "relevant":     len(posts),
            "elapsed_sec":  elapsed,
            "scraped_at":   datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
            "error":        None if articles else "All tiers exhausted",
            "total_words":  sum(a.get("word_count", 0) for a in articles),
        }


# ══════════════════════════════════════════════════════════════════════════
# ASYNC RUNNER
# ══════════════════════════════════════════════════════════════════════════

async def _run_async(outlets: list, concurrency: int) -> list:
    semaphore  = asyncio.Semaphore(concurrency)
    connector  = None
    session    = None

    if HAS_AIOHTTP:
        connector = aiohttp.TCPConnector(
            limit=concurrency * 3,
            ttl_dns_cache=300,
            ssl=False,
            enable_cleanup_closed=True,
        )
        session = aiohttp.ClientSession(
            connector=connector,
            headers={"User-Agent": _ua()},
        )

    browser        = None
    playwright_ctx = None

    if HAS_PLAYWRIGHT:
        try:
            playwright_ctx = await async_playwright().start()
            browser = await playwright_ctx.chromium.launch(
                headless=True,
                args=[
                    "--no-sandbox", "--disable-setuid-sandbox",
                    "--disable-dev-shm-usage", "--disable-gpu",
                    "--disable-web-security",
                    "--disable-features=IsolateOrigins,site-per-process",
                    "--no-first-run", "--no-default-browser-check",
                    "--disable-background-networking", "--disable-sync",
                    "--mute-audio", "--ignore-certificate-errors",
                    "--disable-blink-features=AutomationControlled",
                ],
            )
            logger.info("✅ Playwright Chromium launched")
        except Exception as e:
            logger.warning(f"Playwright unavailable: {e}")
            browser, playwright_ctx = None, None

    results = []
    try:
        tasks   = [_scrape_one(o, session, browser, semaphore) for o in outlets]
        results = await asyncio.gather(*tasks, return_exceptions=False)
    except Exception as e:
        logger.error(f"Gather error: {e}")
    finally:
        for obj, method in [
            (browser,        "close"),
            (playwright_ctx, "stop"),
            (session,        "close"),
            (connector,      "close"),
        ]:
            if obj:
                try:
                    await getattr(obj, method)()
                except Exception:
                    pass

    return list(results)


# ══════════════════════════════════════════════════════════════════════════
# PUBLIC API
# ══════════════════════════════════════════════════════════════════════════

def run_scraper(outlets: list, concurrency: int = 5) -> list:
    """
    Main entry point.

    Returns list of result dicts. Each includes:
      - articles  : raw scraped article dicts
      - posts     : List[Post] — keyword-filtered, ready for MongoDB + AI
      - count     : total articles scraped
      - relevant  : articles matching peace/hate keywords
      - status    : 'success' | 'failed'
    """
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            raise RuntimeError("closed")
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    try:
        return loop.run_until_complete(_run_async(outlets, concurrency))
    except Exception as e:
        logger.error(f"run_scraper fatal: {e}")
        ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        return [
            {
                "name":        o.get("name", "?"),
                "website":     _get_domain(o),
                "url":         _build_url(o),
                "category":    o.get("category", "general"),
                "priority":    o.get("priority", 3),
                "status":      "failed",
                "tier":        "Failed",
                "articles":    [],
                "posts":       [],
                "count":       0,
                "relevant":    0,
                "elapsed_sec": 0,
                "scraped_at":  ts,
                "error":       str(e),
                "total_words": 0,
            }
            for o in outlets
        ]
