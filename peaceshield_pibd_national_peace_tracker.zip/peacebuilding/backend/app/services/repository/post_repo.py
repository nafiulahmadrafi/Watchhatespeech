"""
app/services/repository/post_repo.py
All MongoDB operations for posts, submissions, jobs, and analytics.
"""

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from motor.motor_asyncio import AsyncIOMotorDatabase
from pymongo import ReplaceOne, DESCENDING
from pymongo.errors import BulkWriteError
from loguru import logger

from app.models.schemas import Post, ScraperJob, SubmissionResponse


class PostRepository:

    def __init__(self, db: AsyncIOMotorDatabase):
        self._posts = db["posts"]
        self._submissions = db["submissions"]
        self._jobs = db["scraper_jobs"]

    # ── Posts ─────────────────────────────────────────────────────────────

    async def bulk_upsert(self, posts: List[Post]) -> int:
        if not posts:
            return 0
        ops = [
            ReplaceOne({"source_url": p.source_url}, p.model_dump(), upsert=True)
            if p.source_url
            else ReplaceOne({"id": p.id}, p.model_dump(), upsert=True)
            for p in posts
        ]
        try:
            result = await self._posts.bulk_write(ops, ordered=False)
            return result.upserted_count + result.modified_count
        except BulkWriteError as exc:
            logger.warning(f"Bulk write partial error: {exc.details}")
            return exc.details.get("nInserted", 0)

    async def get_recent_threats(
        self, limit: int = 50, label_filter: Optional[str] = None
    ) -> List[Dict]:
        query: Dict[str, Any] = {}
        if label_filter:
            query["label"] = label_filter
        else:
            query["label"] = {"$in": ["Hate", "Offensive"]}

        cursor = (
            self._posts.find(query, {"_id": 0, "metadata": 0})
            .sort("scraped_at", DESCENDING)
            .limit(limit)
        )
        return await cursor.to_list(length=limit)

    async def get_stats_24h(self) -> Dict[str, Any]:
        since = datetime.utcnow() - timedelta(hours=24)
        pipeline = [
            {"$match": {"scraped_at": {"$gte": since}}},
            {"$group": {
                "_id": "$label",
                "count": {"$sum": 1},
                "avg_risk": {"$avg": "$risk_score"},
            }},
        ]
        raw = await self._posts.aggregate(pipeline).to_list(length=10)
        stats = {r["_id"]: {"count": r["count"], "avg_risk": round(r["avg_risk"], 1)} for r in raw}
        return stats

    async def get_top_keywords(self, limit: int = 12) -> List[Dict]:
        pipeline = [
            {"$unwind": "$keywords_matched"},
            {"$group": {"_id": "$keywords_matched", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
            {"$limit": limit},
            {"$project": {"keyword": "$_id", "count": 1, "_id": 0}},
        ]
        return await self._posts.aggregate(pipeline).to_list(length=limit)

    async def get_hourly_trend(self, hours: int = 24) -> List[Dict]:
        since = datetime.utcnow() - timedelta(hours=hours)
        pipeline = [
            {"$match": {"scraped_at": {"$gte": since}}},
            {"$group": {
                "_id": {
                    "hour": {"$hour": "$scraped_at"},
                    "label": "$label",
                },
                "count": {"$sum": 1},
            }},
            {"$sort": {"_id.hour": 1}},
        ]
        return await self._posts.aggregate(pipeline).to_list(length=100)

    async def full_text_search(self, query: str, limit: int = 20) -> List[Dict]:
        cursor = (
            self._posts.find(
                {"$text": {"$search": query}},
                {"score": {"$meta": "textScore"}, "_id": 0},
            )
            .sort([("score", {"$meta": "textScore"})])
            .limit(limit)
        )
        return await cursor.to_list(length=limit)

    # ── Submissions ───────────────────────────────────────────────────────

    async def save_submission(self, doc: Dict) -> str:
        await self._submissions.insert_one(doc)
        return doc["submission_id"]

    async def get_submissions(self, limit: int = 20) -> List[Dict]:
        cursor = (
            self._submissions.find({}, {"_id": 0})
            .sort("submitted_at", DESCENDING)
            .limit(limit)
        )
        return await cursor.to_list(length=limit)

    # ── Scraper Jobs ──────────────────────────────────────────────────────

    async def create_job(self, job: ScraperJob) -> str:
        await self._jobs.insert_one(job.model_dump())
        return job.id

    async def update_job(self, job: ScraperJob) -> None:
        await self._jobs.replace_one({"id": job.id}, job.model_dump(), upsert=True)

    async def get_job(self, job_id: str) -> Optional[Dict]:
        doc = await self._jobs.find_one({"id": job_id}, {"_id": 0})
        return doc
