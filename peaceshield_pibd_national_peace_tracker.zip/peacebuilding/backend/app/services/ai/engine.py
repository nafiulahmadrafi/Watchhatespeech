"""
app/services/ai/engine.py

Bangla-BERT Hate Speech Detection Engine
=========================================
• Loads 'hate-speech-report/bangla-bert-hate-speech' once into RAM
• Lazy-loads on first inference request (not at import time)
• Runs blocking torch inference in a ThreadPoolExecutor
• Implements batch processing to handle VPS memory constraints
• Maps model outputs → HateLabel + risk_score

Model labels (from HuggingFace model card):
  LABEL_0 = Hate
  LABEL_1 = Offensive
  LABEL_2 = Neutral
"""

import asyncio
from concurrent.futures import ThreadPoolExecutor
from threading import Lock
from typing import List, Optional
import time

from loguru import logger

from app.core.config import settings
from app.models.schemas import AIResult, HateLabel

# ── Label Mapping ─────────────────────────────────────────────────────────
LABEL_MAP = {
    "LABEL_0": HateLabel.HATE,
    "LABEL_1": HateLabel.OFFENSIVE,
    "LABEL_2": HateLabel.NEUTRAL,
    # Fallbacks if model uses string labels
    "hate": HateLabel.HATE,
    "offensive": HateLabel.OFFENSIVE,
    "neutral": HateLabel.NEUTRAL,
}

RISK_WEIGHTS = {
    HateLabel.HATE: 100.0,
    HateLabel.OFFENSIVE: 55.0,
    HateLabel.NEUTRAL: 5.0,
}

# ── Thread-safe singleton ─────────────────────────────────────────────────
_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="ai-worker")
_model_lock = Lock()


class BanglaBERTEngine:
    """
    Singleton AI engine. Thread-safe lazy loader.
    Use `get_engine()` to obtain the shared instance.
    """

    def __init__(self):
        self._pipeline = None
        self._loaded = False
        self._load_time: Optional[float] = None

    # ── Lazy Loading ──────────────────────────────────────────────────────

    def _load_model(self) -> None:
        """Blocking model load — called once inside thread pool."""
        with _model_lock:
            if self._loaded:
                return

            logger.info(f"Loading Bangla-BERT: {settings.MODEL_NAME}")
            t0 = time.time()

            try:
                from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
                import torch

                device_id = 0 if settings.DEVICE == "cuda" else -1

                tokenizer = AutoTokenizer.from_pretrained(
                    settings.MODEL_NAME,
                    cache_dir=settings.MODEL_CACHE_DIR,
                    use_fast=True,
                )
                model = AutoModelForSequenceClassification.from_pretrained(
                    settings.MODEL_NAME,
                    cache_dir=settings.MODEL_CACHE_DIR,
                    # Low-memory options for VPS
                    low_cpu_mem_usage=True,
                    torch_dtype=torch.float32,
                )

                if settings.DEVICE == "cpu":
                    # Quantise to int8 → ~50% RAM reduction on CPU VPS
                    try:
                        import torch.quantization
                        model = torch.quantization.quantize_dynamic(
                            model, {torch.nn.Linear}, dtype=torch.qint8
                        )
                        logger.info("Model quantised to int8 (CPU mode).")
                    except Exception as qe:
                        logger.warning(f"Quantisation skipped: {qe}")

                self._pipeline = pipeline(
                    "text-classification",
                    model=model,
                    tokenizer=tokenizer,
                    device=device_id,
                    return_all_scores=True,
                    truncation=True,
                    max_length=settings.MODEL_MAX_LENGTH,
                    batch_size=settings.MODEL_BATCH_SIZE,
                )

                self._loaded = True
                self._load_time = time.time() - t0
                logger.success(f"Bangla-BERT ready in {self._load_time:.1f}s")

            except Exception as exc:
                logger.error(f"Model load failed: {exc}")
                self._pipeline = None
                self._loaded = False
                raise

    # ── Inference ─────────────────────────────────────────────────────────

    def _infer(self, texts: List[str]) -> List[AIResult]:
        """Blocking inference — runs in thread pool."""
        if not self._loaded:
            self._load_model()

        if self._pipeline is None:
            return [self._fallback_result(t) for t in texts]

        try:
            raw_outputs = self._pipeline(texts)
        except Exception as exc:
            logger.error(f"Inference error: {exc}")
            return [self._fallback_result(t) for t in texts]

        results = []
        for output in raw_outputs:
            # output = [{"label": "LABEL_0", "score": 0.9}, ...]
            scores_map = {
                LABEL_MAP.get(item["label"], HateLabel.NEUTRAL): round(item["score"], 4)
                for item in output
            }
            best = max(output, key=lambda x: x["score"])
            label = LABEL_MAP.get(best["label"], HateLabel.NEUTRAL)
            confidence = round(best["score"], 4)
            risk_score = round(RISK_WEIGHTS[label] * confidence, 1)

            results.append(AIResult(
                label=label,
                confidence=confidence,
                risk_score=risk_score,
                scores={k.value: v for k, v in scores_map.items()},
            ))

        return results

    async def analyse(self, text: str) -> AIResult:
        """Async single-text analysis."""
        loop = asyncio.get_event_loop()
        results = await loop.run_in_executor(_executor, self._infer, [text])
        return results[0]

    async def analyse_batch(self, texts: List[str]) -> List[AIResult]:
        """Async batch analysis — more efficient for scraper pipeline."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(_executor, self._infer, texts)

    async def warm_up(self) -> None:
        """Pre-load model at startup (non-blocking)."""
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(_executor, self._load_model)

    @property
    def is_ready(self) -> bool:
        return self._loaded and self._pipeline is not None

    @staticmethod
    def _fallback_result(text: str) -> AIResult:
        """Keyword heuristic when model unavailable."""
        hate_words = ["দাঙ্গা", "হত্যা", "ধর্ষণ", "জঙ্গি", "সন্ত্রাস"]
        lower = text.lower()
        is_hate = any(w in lower for w in hate_words)
        label = HateLabel.HATE if is_hate else HateLabel.NEUTRAL
        return AIResult(
            label=label,
            confidence=0.6,
            risk_score=60.0 if is_hate else 5.0,
            scores={"Hate": 0.6 if is_hate else 0.1, "Neutral": 0.4 if is_hate else 0.9, "Offensive": 0.0},
        )


# ── Singleton ─────────────────────────────────────────────────────────────
_engine_instance: Optional[BanglaBERTEngine] = None


def get_engine() -> BanglaBERTEngine:
    global _engine_instance
    if _engine_instance is None:
        _engine_instance = BanglaBERTEngine()
    return _engine_instance
