"""
app/models/schemas.py
All domain models — Pydantic v2 with strict validation.
"""

from __future__ import annotations
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field, HttpUrl, field_validator
import uuid


# ── Enums ──────────────────────────────────────────────────────────────────

class HateLabel(str, Enum):
    HATE      = "Hate"
    OFFENSIVE = "Offensive"
    NEUTRAL   = "Neutral"


class PostSource(str, Enum):
    FACEBOOK  = "Facebook"
    TWITTER   = "Twitter"
    YOUTUBE   = "YouTube"
    NEWS      = "News"
    SUBMITTED = "Submitted"
    UNKNOWN   = "Unknown"


class JobStatus(str, Enum):
    PENDING   = "pending"
    RUNNING   = "running"
    COMPLETED = "completed"
    FAILED    = "failed"


# ── AI Result ─────────────────────────────────────────────────────────────

class AIResult(BaseModel):
    label: HateLabel
    confidence: float = Field(ge=0.0, le=1.0)
    risk_score: float = Field(ge=0.0, le=100.0)
    scores: Dict[str, float]              # Raw logits per class


# ── Scraped Post ───────────────────────────────────────────────────────────

class Post(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    content: str
    source: PostSource = PostSource.UNKNOWN
    source_url: Optional[str] = None
    author: Optional[str] = None
    keywords_matched: List[str] = Field(default_factory=list)
    label: Optional[HateLabel] = None
    confidence: Optional[float] = None
    risk_score: float = 0.0
    ai_scores: Dict[str, float] = Field(default_factory=dict)
    scraped_at: datetime = Field(default_factory=datetime.utcnow)
    analysed_at: Optional[datetime] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

    @field_validator("keywords_matched", mode="before")
    @classmethod
    def dedup(cls, v):
        return list(dict.fromkeys(v or []))


# ── Public Submission ──────────────────────────────────────────────────────

class SubmissionRequest(BaseModel):
    content: str = Field(..., min_length=5, max_length=2000,
                         description="Bangla text to analyse")
    source_hint: Optional[str] = Field(default=None, max_length=200)
    reporter_type: Optional[str] = Field(default="citizen")

class SubmissionResponse(BaseModel):
    submission_id: str
    label: HateLabel
    confidence: float
    risk_score: float
    message: str
    submitted_at: datetime


# ── Dashboard ─────────────────────────────────────────────────────────────

class PeaceMeter(BaseModel):
    score: float = Field(ge=0.0, le=100.0)    # 0 = extreme tension, 100 = peaceful
    level: str                                 # "Critical" | "High" | "Medium" | "Low"
    hate_24h: int
    offensive_24h: int
    neutral_24h: int
    total_24h: int
    trend: str                                 # "rising" | "falling" | "stable"


class DashboardStats(BaseModel):
    peace_meter: PeaceMeter
    recent_threats: List[Dict[str, Any]]
    top_keywords: List[Dict[str, Any]]
    hourly_trend: List[Dict[str, Any]]


# ── Scraper Job ───────────────────────────────────────────────────────────

class ScraperJob(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    keywords: List[str]
    status: JobStatus = JobStatus.PENDING
    posts_found: int = 0
    posts_analysed: int = 0
    error_log: List[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
