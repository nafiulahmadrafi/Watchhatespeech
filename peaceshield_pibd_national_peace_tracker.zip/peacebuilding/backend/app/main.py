"""
app/main.py
National Peace Tracker — Political Insights BD (PIBD)
Developed by Ahmad Rafi | pibbd.org
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from loguru import logger

from app.core.config import settings
from app.core.logger import setup_logger
from app.db.mongodb import connect_db, disconnect_db, get_db
from app.db.indexes import ensure_indexes
from app.api.v1.router import api_router

setup_logger()

limiter = Limiter(key_func=get_remote_address, default_limits=[settings.RATE_LIMIT])

APP_DESCRIPTION = """
## National Peace Tracker
**Political Insights BD (PIBD)** — [pibbd.org](https://pibbd.org)

Developed by **Ahmad Rafi**

---

Real-time Bangla hate speech & misinformation detection engine powering
the National Peace Tracker dashboard on Political Insights BD.

### Features
- 🤖 **Bangla-BERT AI** — hate/offensive/neutral classification
- 🕷️ **94+ news portals** — concurrent 5-tier scraping engine
- 🕊️ **Peace Meter** — live social tension index
- 📊 **Live threat feed** — keyword-indexed, full-text searchable
- 📝 **Public submission portal** — citizen reporting with instant AI verdict
"""


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🕊️  National Peace Tracker (PIBD) starting up...")

    await connect_db()
    db = get_db()
    await ensure_indexes(db)

    from app.services.ai.engine import get_engine
    import asyncio
    asyncio.create_task(get_engine().warm_up())
    logger.info("🤖 Bangla-BERT warm-up scheduled.")

    from app.services.scraper.scheduler import start_scheduler
    start_scheduler()
    logger.info("🕷️  Scraper scheduler started.")

    yield

    from app.services.scraper.scheduler import stop_scheduler
    stop_scheduler()
    await disconnect_db()
    logger.info("National Peace Tracker shutdown complete.")


def create_app() -> FastAPI:
    app = FastAPI(
        title="National Peace Tracker — PIBD",
        description=APP_DESCRIPTION,
        version=settings.APP_VERSION,
        contact={
            "name":  "Ahmad Rafi | Political Insights BD",
            "url":   "https://pibbd.org",
            "email": "info@pibbd.org",
        },
        license_info={
            "name": "© Political Insights BD (PIBD)",
            "url":  "https://pibbd.org",
        },
        docs_url="/api/docs",
        redoc_url="/api/redoc",
        lifespan=lifespan,
    )

    app.state.limiter = limiter
    app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
    app.add_middleware(GZipMiddleware, minimum_size=500)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.ALLOWED_ORIGINS,
        allow_credentials=True,
        allow_methods=["GET", "POST"],
        allow_headers=["*"],
    )

    app.include_router(api_router)

    @app.get("/health", tags=["System"])
    async def health():
        return {
            "status":    "ok",
            "app":       "National Peace Tracker",
            "platform":  "Political Insights BD (PIBD)",
            "developer": "Ahmad Rafi",
            "website":   "https://pibbd.org",
            "version":   settings.APP_VERSION,
        }

    return app


app = create_app()
