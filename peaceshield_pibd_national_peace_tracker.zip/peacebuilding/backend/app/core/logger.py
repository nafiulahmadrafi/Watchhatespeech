"""
app/core/logger.py
Structured logging with Loguru — replaces stdlib logging.
"""

import sys
from loguru import logger


def setup_logger() -> None:
    logger.remove()
    logger.add(
        sys.stdout,
        format=(
            "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | "
            "<level>{level: <8}</level> | "
            "<cyan>{name}</cyan>:<cyan>{line}</cyan> — <level>{message}</level>"
        ),
        level="INFO",
        colorize=True,
    )
    logger.add(
        "/app/logs/peaceshield_{time:YYYY-MM-DD}.log",
        rotation="00:00",
        retention="14 days",
        compression="gz",
        level="WARNING",
        enqueue=True,                             # async-safe
    )


setup_logger()
