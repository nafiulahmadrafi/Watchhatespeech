"""
app/core/config.py
Production-grade settings with environment validation.
"""

from functools import lru_cache
from typing import List
from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # ── App ───────────────────────────────────────────────────────────────
    APP_NAME: str = "PeaceShield BD"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: str = Field(default="production", validation_alias="ENVIRONMENT")
    DEBUG: bool = Field(default=False)

    # ── Security ──────────────────────────────────────────────────────────
    SECRET_KEY: str = Field(..., min_length=32)
    ALLOWED_ORIGINS: List[str] = Field(
        default=["http://localhost:3000", "https://peaceshield.bd"]
    )

    # ── MongoDB ───────────────────────────────────────────────────────────
    MONGODB_URI: str = Field(default="mongodb://localhost:27017")
    MONGODB_DB: str = Field(default="peaceshield")

    # ── AI Model ──────────────────────────────────────────────────────────
    MODEL_NAME: str = "hate-speech-report/bangla-bert-hate-speech"
    MODEL_CACHE_DIR: str = "/app/.model_cache"
    MODEL_MAX_LENGTH: int = 512
    MODEL_BATCH_SIZE: int = 8
    DEVICE: str = "cpu"                          # "cuda" on GPU VPS

    # ── Scraper ───────────────────────────────────────────────────────────
    SCRAPER_CONCURRENCY: int = 3
    SCRAPER_INTERVAL_MINUTES: int = 30
    SCRAPER_TIMEOUT_MS: int = 25_000

    # ── Rate Limiting ─────────────────────────────────────────────────────
    RATE_LIMIT: str = "30/minute"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
