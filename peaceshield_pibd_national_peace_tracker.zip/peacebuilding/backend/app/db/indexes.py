"""
app/db/indexes.py
Ensures all required MongoDB indexes exist on startup.
Keyword-based text index with Bangla-aware weights.
"""

from motor.motor_asyncio import AsyncIOMotorDatabase
from pymongo import ASCENDING, DESCENDING, TEXT
from loguru import logger


async def ensure_indexes(db: AsyncIOMotorDatabase) -> None:
    # ── posts ──────────────────────────────────────────────────────────────
    posts = db["posts"]

    await posts.create_index(
        [("content", TEXT), ("source", TEXT), ("keywords_matched", TEXT)],
        name="text_search_idx",
        weights={"content": 10, "keywords_matched": 5, "source": 1},
        default_language="none",          # Must be "none" for Bangla
    )
    await posts.create_index(
        [("source_url", ASCENDING)],
        name="source_url_unique_idx",
        unique=True,
        sparse=True,
    )
    await posts.create_index(
        [("label", ASCENDING), ("scraped_at", DESCENDING)],
        name="label_date_idx",
    )
    await posts.create_index(
        [("risk_score", DESCENDING)],
        name="risk_score_idx",
    )
    await posts.create_index(
        [("keywords_matched", ASCENDING)],
        name="keywords_idx",
    )

    # ── submissions ────────────────────────────────────────────────────────
    subs = db["submissions"]
    await subs.create_index([("submitted_at", DESCENDING)], name="sub_date_idx")
    await subs.create_index([("risk_score", DESCENDING)], name="sub_risk_idx")

    # ── scraper_jobs ───────────────────────────────────────────────────────
    jobs = db["scraper_jobs"]
    await jobs.create_index(
        [("status", ASCENDING), ("created_at", DESCENDING)],
        name="job_status_idx",
    )

    logger.success("All MongoDB indexes ensured.")
