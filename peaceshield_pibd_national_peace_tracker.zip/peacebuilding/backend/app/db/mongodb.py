"""
app/db/mongodb.py
Async MongoDB client using Motor — singleton pattern for connection pooling.
"""

from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from loguru import logger
from app.core.config import settings


class MongoDB:
    client: AsyncIOMotorClient | None = None
    db: AsyncIOMotorDatabase | None = None


_mongo = MongoDB()


async def connect_db() -> None:
    logger.info("Connecting to MongoDB...")
    _mongo.client = AsyncIOMotorClient(
        settings.MONGODB_URI,
        serverSelectionTimeoutMS=5_000,
        maxPoolSize=20,
        minPoolSize=2,
    )
    _mongo.db = _mongo.client[settings.MONGODB_DB]
    await _mongo.client.admin.command("ping")
    logger.success(f"MongoDB connected → db='{settings.MONGODB_DB}'")


async def disconnect_db() -> None:
    if _mongo.client:
        _mongo.client.close()
        logger.info("MongoDB disconnected.")


def get_db() -> AsyncIOMotorDatabase:
    if _mongo.db is None:
        raise RuntimeError("Database not initialised. Call connect_db() first.")
    return _mongo.db
