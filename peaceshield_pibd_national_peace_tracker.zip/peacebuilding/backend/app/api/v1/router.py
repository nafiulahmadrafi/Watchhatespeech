"""
app/api/v1/router.py  +  app/main.py combined bootstrap
"""

# ── router.py ──────────────────────────────────────────────────────────────
from fastapi import APIRouter
from app.api.v1.endpoints.analyse import router as analyse_router
from app.api.v1.endpoints.dashboard import router as dashboard_router
from app.api.v1.endpoints.scraper import router as scraper_router

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(analyse_router, tags=["Analysis"])
api_router.include_router(dashboard_router, tags=["Dashboard"])
api_router.include_router(scraper_router, prefix="/scraper", tags=["Scraper"])
