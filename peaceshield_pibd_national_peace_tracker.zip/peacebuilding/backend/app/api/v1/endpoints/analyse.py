"""
app/api/v1/endpoints/analyse.py
POST /analyse — direct text analysis endpoint (internal + public).
"""

from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Request
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.db.mongodb import get_db
from app.models.schemas import SubmissionRequest, SubmissionResponse, HateLabel
from app.services.ai.engine import get_engine
from app.services.repository.post_repo import PostRepository
import uuid

router = APIRouter()

LABEL_MESSAGES = {
    HateLabel.HATE:      "⚠️ উচ্চ ঝুঁকি: এই বিষয়বস্তুতে ঘৃণামূলক বক্তব্য সনাক্ত হয়েছে।",
    HateLabel.OFFENSIVE: "🔶 মাঝারি ঝুঁকি: আপত্তিকর ভাষা সনাক্ত হয়েছে।",
    HateLabel.NEUTRAL:   "✅ কম ঝুঁকি: কোনো সমস্যা সনাক্ত হয়নি।",
}


@router.post(
    "/submit",
    response_model=SubmissionResponse,
    summary="Public: Submit text for hate-speech analysis",
)
async def submit_text(
    payload: SubmissionRequest,
    request: Request,
    db: AsyncIOMotorDatabase = Depends(get_db),
):
    engine = get_engine()
    result = await engine.analyse(payload.content)
    repo = PostRepository(db)

    submission_id = str(uuid.uuid4())
    doc = {
        "submission_id": submission_id,
        "content": payload.content,
        "source_hint": payload.source_hint,
        "reporter_type": payload.reporter_type,
        "label": result.label.value,
        "confidence": result.confidence,
        "risk_score": result.risk_score,
        "ai_scores": result.scores,
        "submitted_at": datetime.utcnow(),
    }
    await repo.save_submission(doc)

    return SubmissionResponse(
        submission_id=submission_id,
        label=result.label,
        confidence=result.confidence,
        risk_score=result.risk_score,
        message=LABEL_MESSAGES[result.label],
        submitted_at=doc["submitted_at"],
    )


@router.post(
    "/analyse",
    summary="Internal: Analyse raw text (API key protected in prod)",
)
async def analyse_raw(payload: SubmissionRequest):
    engine = get_engine()
    result = await engine.analyse(payload.content)
    return {
        "label": result.label,
        "confidence": result.confidence,
        "risk_score": result.risk_score,
        "scores": result.scores,
        "model_ready": engine.is_ready,
    }
