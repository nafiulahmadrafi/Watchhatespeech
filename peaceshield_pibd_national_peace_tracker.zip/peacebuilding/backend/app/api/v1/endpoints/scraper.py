"""
app/api/v1/endpoints/scraper.py

Scraper management endpoints:
  POST /scraper/trigger          — manually trigger a scrape cycle
  GET  /scraper/status           — current cycle number + last job
  GET  /scraper/portals          — list all registered portals
  GET  /scraper/portals/{domain} — info on a specific portal
  GET  /scraper/jobs/{job_id}    — job status
"""

from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from motor.motor_asyncio import AsyncIOMotorDatabase
from loguru import logger

from app.core.security import require_api_key
from app.db.mongodb import get_db
from app.models.schemas import ScraperJob
from app.services.repository.post_repo import PostRepository
from app.services.scraper.news_portals import (
    NEWS_PORTALS, TOTAL_PORTALS,
    get_portals_by_category, get_portals_for_cycle, summary,
)
from app.services.scraper.scheduler import get_cycle_number

router = APIRouter()


def _get_repo(request: Request) -> PostRepository:
    return PostRepository(request.app.state.db.get_database())


# ── Trigger manual scrape ──────────────────────────────────────────────────

@router.post(
    "/trigger",
    summary="Manually trigger a scrape cycle",
    status_code=status.HTTP_202_ACCEPTED,
    dependencies=[Depends(require_api_key)],
)
async def trigger_scrape(
    priority: int = Query(default=1, ge=1, le=4, description="Max priority level to include"),
    request: Request = None,
    repo: PostRepository = Depends(_get_repo),
):
    from app.services.scraper.scheduler import _safe_cycle
    import asyncio
    asyncio.create_task(_safe_cycle())
    return {
        "message": "Scrape cycle triggered",
        "cycle": get_cycle_number(),
        "portals_in_cycle": len(get_portals_for_cycle(get_cycle_number())),
        "triggered_at": datetime.utcnow().isoformat(),
    }


# ── Scraper status ─────────────────────────────────────────────────────────

@router.get("/status", summary="Scraper scheduler status")
async def scraper_status(repo: PostRepository = Depends(_get_repo)):
    from app.services.scraper.scheduler import _scheduler
    cycle = get_cycle_number()
    next_run = None
    if _scheduler and _scheduler.running:
        job = _scheduler.get_job("peaceshield_scraper")
        if job and job.next_run_time:
            next_run = job.next_run_time.isoformat()

    return {
        "scheduler_running": bool(_scheduler and _scheduler.running),
        "cycle_number":      cycle,
        "next_run":          next_run,
        "portals_total":     TOTAL_PORTALS,
        "next_cycle_portals":len(get_portals_for_cycle(cycle)),
        "registry_summary":  summary(),
    }


# ── Portal registry ────────────────────────────────────────────────────────

@router.get("/portals", summary="List all registered news portals")
async def list_portals(
    category: Optional[str] = Query(default=None),
    priority: Optional[int] = Query(default=None, ge=1, le=4),
):
    portals = NEWS_PORTALS
    if category:
        portals = [p for p in portals if p["category"] == category]
    if priority:
        portals = [p for p in portals if p["priority"] == priority]

    return {
        "total": len(portals),
        "filters": {"category": category, "priority": priority},
        "portals": portals,
    }


@router.get("/portals/categories", summary="List portal categories")
async def portal_categories():
    cats: dict = {}
    for p in NEWS_PORTALS:
        c = p["category"]
        cats[c] = cats.get(c, 0) + 1
    return {"categories": cats}


@router.get("/portals/{domain}", summary="Get info on a specific portal")
async def get_portal(domain: str):
    portal = next((p for p in NEWS_PORTALS if p["website"] == domain), None)
    if not portal:
        raise HTTPException(status_code=404, detail=f"Portal '{domain}' not in registry.")
    return portal


# ── Job status ─────────────────────────────────────────────────────────────

@router.get("/jobs/{job_id}", summary="Get scrape job status")
async def get_job(job_id: str, repo: PostRepository = Depends(_get_repo)):
    job = await repo.get_job(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")
    return job


@router.get("/jobs", summary="List recent scrape jobs")
async def list_jobs(
    limit: int = Query(default=10, ge=1, le=50),
    repo: PostRepository = Depends(_get_repo),
):
    from app.db.mongodb import get_db
    jobs_col = repo._jobs
    cursor   = jobs_col.find({}, {"_id": 0}).sort("created_at", -1).limit(limit)
    jobs     = await cursor.to_list(length=limit)
    return {"count": len(jobs), "jobs": jobs}
