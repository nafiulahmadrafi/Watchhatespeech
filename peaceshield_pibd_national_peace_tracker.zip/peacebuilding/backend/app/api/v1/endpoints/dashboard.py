"""
app/api/v1/endpoints/dashboard.py
Real-time dashboard data: Peace Meter + threat feed + trends.
"""

from fastapi import APIRouter, Depends
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.db.mongodb import get_db
from app.models.schemas import PeaceMeter, DashboardStats
from app.services.repository.post_repo import PostRepository

router = APIRouter()


def compute_peace_meter(stats_24h: dict) -> PeaceMeter:
    """
    Peace Meter Algorithm:
      score = 100 − (hate_weight × hate_count + offensive_weight × offensive_count) / total
    Clamped 0–100. Lower = more tension.
    """
    hate_data = stats_24h.get("Hate", {"count": 0})
    off_data  = stats_24h.get("Offensive", {"count": 0})
    neu_data  = stats_24h.get("Neutral", {"count": 0})

    hate_count = hate_data["count"]
    off_count  = off_data["count"]
    neu_count  = neu_data["count"]
    total = hate_count + off_count + neu_count or 1

    weighted_tension = (hate_count * 1.0 + off_count * 0.4) / total * 100
    score = round(max(0.0, min(100.0, 100.0 - weighted_tension)), 1)

    if score >= 75:
        level, trend = "Low", "stable"
    elif score >= 50:
        level, trend = "Medium", "rising" if hate_count > neu_count else "stable"
    elif score >= 25:
        level, trend = "High", "rising"
    else:
        level, trend = "Critical", "rising"

    return PeaceMeter(
        score=score,
        level=level,
        hate_24h=hate_count,
        offensive_24h=off_count,
        neutral_24h=neu_count,
        total_24h=total,
        trend=trend,
    )


@router.get(
    "/dashboard",
    response_model=DashboardStats,
    summary="Live dashboard: Peace Meter + threat feed",
)
async def get_dashboard(db: AsyncIOMotorDatabase = Depends(get_db)):
    repo = PostRepository(db)

    stats_24h    = await repo.get_stats_24h()
    recent       = await repo.get_recent_threats(limit=30)
    top_keywords = await repo.get_top_keywords(limit=12)
    hourly_trend = await repo.get_hourly_trend(hours=24)

    peace_meter = compute_peace_meter(stats_24h)

    return DashboardStats(
        peace_meter=peace_meter,
        recent_threats=recent,
        top_keywords=top_keywords,
        hourly_trend=hourly_trend,
    )


@router.get("/submissions", summary="Recent public submissions")
async def get_submissions(
    limit: int = 20,
    db: AsyncIOMotorDatabase = Depends(get_db),
):
    repo = PostRepository(db)
    return {"submissions": await repo.get_submissions(limit=limit)}


@router.get("/search", summary="Full-text search across posts")
async def search_posts(
    q: str,
    limit: int = 20,
    db: AsyncIOMotorDatabase = Depends(get_db),
):
    repo = PostRepository(db)
    results = await repo.full_text_search(q, limit=limit)
    return {"query": q, "count": len(results), "results": results}


@router.get("/health", summary="AI engine health check")
async def health():
    from app.services.ai.engine import get_engine
    engine = get_engine()
    return {"status": "ok", "model_loaded": engine.is_ready}
