db = db.getSiblingDB('peaceshield');
db.createCollection('posts');
db.createCollection('submissions');
db.createCollection('scraper_jobs');
print('MongoDB peaceshield database initialised.');
