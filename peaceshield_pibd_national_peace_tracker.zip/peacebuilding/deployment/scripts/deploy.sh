#!/bin/bash
# ─────────────────────────────────────────────────────────
# PeaceShield BD — Hostinger VPS Deployment Script
# Usage: bash deploy.sh
# Requires: Docker, Docker Compose, .env file
# ─────────────────────────────────────────────────────────
set -euo pipefail

echo "🕊️  PeaceShield BD — Deploy Starting..."

# 1. Check .env exists
if [ ! -f .env ]; then
  echo "❌ .env file not found. Copy .env.example and fill values."
  exit 1
fi

# 2. Pull latest (if git repo)
if [ -d .git ]; then
  echo "📥 Pulling latest code..."
  git pull --rebase origin main
fi

# 3. Build images
echo "🔨 Building Docker images..."
docker compose build --no-cache --parallel

# 4. Pre-download Bangla-BERT model into named volume
# (avoids downloading on every restart)
echo "🤖 Pre-warming Bangla-BERT model..."
docker compose run --rm \
  -e HF_HUB_DISABLE_PROGRESS_BARS=1 \
  app python -c "
from transformers import AutoTokenizer, AutoModelForSequenceClassification
model = 'hate-speech-report/bangla-bert-hate-speech'
print('Downloading tokenizer...')
AutoTokenizer.from_pretrained(model, cache_dir='/app/.model_cache')
print('Downloading model...')
AutoModelForSequenceClassification.from_pretrained(model, cache_dir='/app/.model_cache')
print('✅ Model cached.')
" || echo "⚠️  Model pre-warm failed (will download on first request)"

# 5. Playwright browsers
echo "🎭 Installing Playwright browsers..."
docker compose run --rm app playwright install chromium --with-deps || true

# 6. Start stack
echo "🚀 Starting services..."
docker compose up -d --remove-orphans

# 7. Wait and health check
echo "⏳ Waiting for API health check..."
sleep 10
MAX_TRIES=12
for i in $(seq 1 $MAX_TRIES); do
  if curl -sf http://localhost:8000/health > /dev/null; then
    echo "✅ API is healthy!"
    break
  fi
  echo "  Attempt $i/$MAX_TRIES..."
  sleep 5
done

# 8. Show logs tail
echo ""
echo "📋 Container status:"
docker compose ps
echo ""
echo "✅ Deploy complete! PeaceShield BD is live."
echo "   API:      http://localhost:8000/api/docs"
echo "   Frontend: http://localhost:3000"
